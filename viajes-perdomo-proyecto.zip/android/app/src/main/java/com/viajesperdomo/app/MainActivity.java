package com.viajesperdomo.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
