# 🚌 Viajes Perdomo - Aplicación Web y Android (APK)

Aplicación oficial de gestión y reservas de pasajes interprovinciales en guaguas Yutong en Cuba, con boletos digitales, código QR offline y flujo automatizado para compilar el **archivo .apk** en **GitHub Actions**.

---

## 🚀 Características
- **Mismas vistas y rutas originales**:
  - `Inicio`: Búsqueda por origen, destino, fecha, cantidad de pasajeros y filtros regionales (Este, Centro, Oeste, Especiales).
  - `Mi Perfil`: Edición de nombre y contraseña, con gestor asignado y correo protegido.
  - `Mis Reservas`: Listado interactivo con códigos de boleto `VP-XXXX`, estado (confirmada, cancelada, etc.), botón de cancelación y **código QR digital**.
  - `Preguntas Frecuentes`: Formas de pago (al abordar en CUP), políticas de cancelación y franquicia de equipaje.
  - `Valorar Agencia`: Calificación por estrellas y reseñas comunitarias.
  - `Acerca de Nosotros`: Historia y detalles de la flota de guaguas Yutong.
- **Códigos QR Offline**: Generación nativa inmediata para mostrar al gestor al abordar sin depender de conexión a internet.
- **API Full-Stack & Modo Offline**: Servidor Express con persistencia y fallback automático a LocalStorage para funcionamiento garantizado en la app móvil.

---

## 📱 Cómo subir a GitHub y obtener tu APK (.apk)

El repositorio ya contiene el workflow configurado en `.github/workflows/build-apk.yml`. Puedes subirlo de dos maneras:

### Opción A: Mediante Git (Recomendado)
```bash
git init
git add .
git commit -m "feat: Viajes Perdomo app lista para compilar APK"
git branch -M main
git remote add origin https://github.com/TU-USUARIO/TU-REPOSITORIO.git
git push -u origin main
```

### Opción B: Subiendo un archivo ZIP a GitHub
Si prefieres comprimir todo en un archivo `.zip`:
1. Comprime los archivos del proyecto (puedes nombrarlo `project.zip` o subirlo descomprimido directamente en GitHub).
2. El workflow incluye la tarea `unzip` que detecta y descomprime automáticamente el archivo `.zip` si fue subido comprimido a la raíz.

---

## 📥 Dónde descargar el APK una vez compilado

1. En tu repositorio de GitHub, haz clic en la pestaña **Actions**.
2. Verás la ejecución del workflow **"Construir APK de Viajes Perdomo"**.
3. Al terminar (toma aproximadamente 2 a 3 minutos), haz clic en la ejecución.
4. Al final de la página, en la sección **Artifacts** (Artefactos), encontrarás:
   - **`Viajes-Perdomo-APK`**: El archivo instalable `viajes-perdomo-debug.apk`.
   - **`Viajes-Perdomo-APK-ZIP`**: Archivo `.zip` con el APK listo para descargar y descomprimir.

---

## 🛠️ Versiones Utilizadas (Sin Conflictos)
- **Node.js**: `22 LTS` (Requerido por Capacitor CLI 8+)
- **Java JDK**: `17 (Eclipse Temurin)` (Compatible al 100% con Gradle 8 y Android SDK)
- **Capacitor**: `@capacitor/core`, `@capacitor/android` v8/latest
- **Vite**: `8.3.0` + React 19 + Tailwind CSS
