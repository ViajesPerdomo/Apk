import express, { Request, Response } from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import { fileURLToPath } from 'url';
import { ZipArchive } from 'archiver';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

interface Gestor {
  usuario: string;
  nombre: string;
  telefono: string;
  agencia: string;
}

interface Guagua {
  id: string;
  origen: string;
  destino: string;
  unidad: string;
  precio: number;
  moneda: string;
  asientosTotales: number;
  asientosDisp: number;
  salida: string;
  llegada: string;
  region: 'este' | 'centro' | 'oeste' | 'especial';
  oferta: boolean;
  imagen: string;
  activa: boolean;
  caracteristicas: string[];
}

interface Reserva {
  id: string;
  codigo: string;
  guaguaId: string;
  nombre: string; // ruta "La Habana → Santiago de Cuba"
  pasajeroNombre: string;
  email: string;
  ci: string;
  telefono: string;
  gestorCodigo: string;
  fechaViaje: string;
  cantidad: number;
  precioUnitario: number;
  total: number;
  moneda: string;
  estado: 'pendiente' | 'confirmada' | 'cancelada' | 'completada';
  creadoEn: string;
}

interface Valoracion {
  id: string;
  usuarioNombre: string;
  estrellas: number;
  comentario: string;
  fecha: string;
}

interface Usuario {
  id: string;
  nombre: string;
  email: string;
  password?: string;
  gestorCodigo: string;
}

// Initial Mock Data Store
const gestores: Gestor[] = [
  { usuario: 'CR01', nombre: 'Carlos Rodríguez', telefono: '+53 5234 5678', agencia: 'Terminal Central La Habana' },
  { usuario: 'ED04', nombre: 'Elena Díaz', telefono: '+53 5345 6789', agencia: 'Varadero Centro' },
  { usuario: 'MT09', nombre: 'Marcos Torres', telefono: '+53 5456 7890', agencia: 'Santiago de Cuba Sur' },
  { usuario: 'YP12', nombre: 'Yailenys Pérez', telefono: '+53 5567 8901', agencia: 'Holguín Monumento' },
  { usuario: 'AS05', nombre: 'Armando Suárez', telefono: '+53 5678 9012', agencia: 'Trinidad Colonial' }
];

let guaguas: Guagua[] = [
  {
    id: 'g-101',
    origen: 'La Habana',
    destino: 'Varadero',
    unidad: 'Yutong #104 Climatizada',
    precio: 2500,
    moneda: 'CUP',
    asientosTotales: 44,
    asientosDisp: 18,
    salida: '07:30 AM',
    llegada: '10:00 AM',
    region: 'oeste',
    oferta: true,
    imagen: 'https://images.unsplash.com/photo-1544620347-c4fd4a3d5957?auto=format&fit=crop&w=800&q=80',
    activa: true,
    caracteristicas: ['A/C Doble Turbina', 'Música y Video', 'Cargador USB']
  },
  {
    id: 'g-102',
    origen: 'La Habana',
    destino: 'Santiago de Cuba',
    unidad: 'Yutong #302 Gran Confort',
    precio: 5200,
    moneda: 'CUP',
    asientosTotales: 48,
    asientosDisp: 12,
    salida: '06:00 AM',
    llegada: '08:30 PM',
    region: 'este',
    oferta: false,
    imagen: 'https://images.unsplash.com/photo-1570125909232-eb263c188f7e?auto=format&fit=crop&w=800&q=80',
    activa: true,
    caracteristicas: ['Asientos Reclinables 160°', 'WiFi Satelital', 'Nevera a bordo', 'Baño']
  },
  {
    id: 'g-103',
    origen: 'La Habana',
    destino: 'Trinidad',
    unidad: 'Yutong #215 Colonial',
    precio: 3600,
    moneda: 'CUP',
    asientosTotales: 44,
    asientosDisp: 24,
    salida: '08:15 AM',
    llegada: '01:30 PM',
    region: 'centro',
    oferta: true,
    imagen: 'https://images.unsplash.com/photo-1506015391300-4802dc74de2e?auto=format&fit=crop&w=800&q=80',
    activa: true,
    caracteristicas: ['A/C Confort', 'Espacio para 2 maletas', 'Música ambiental']
  },
  {
    id: 'g-104',
    origen: 'La Habana',
    destino: 'Holguín',
    unidad: 'Yutong #410 Expreso',
    precio: 4800,
    moneda: 'CUP',
    asientosTotales: 48,
    asientosDisp: 8,
    salida: '05:30 AM',
    llegada: '06:00 PM',
    region: 'este',
    oferta: false,
    imagen: 'https://images.unsplash.com/photo-1544620347-c4fd4a3d5957?auto=format&fit=crop&w=800&q=80',
    activa: true,
    caracteristicas: ['Parada Almuerzo en Sancti Spíritus', 'Cargadores individuales', 'WiFi']
  },
  {
    id: 'g-105',
    origen: 'Varadero',
    destino: 'La Habana',
    unidad: 'Yutong #108 Retorno',
    precio: 2500,
    moneda: 'CUP',
    asientosTotales: 44,
    asientosDisp: 30,
    salida: '04:00 PM',
    llegada: '06:45 PM',
    region: 'oeste',
    oferta: false,
    imagen: 'https://images.unsplash.com/photo-1570125909232-eb263c188f7e?auto=format&fit=crop&w=800&q=80',
    activa: true,
    caracteristicas: ['A/C Climatizado', 'Maletero amplio', 'Conductor profesional']
  },
  {
    id: 'g-106',
    origen: 'Santiago de Cuba',
    destino: 'La Habana',
    unidad: 'Yutong #304 Nocturna',
    precio: 5200,
    moneda: 'CUP',
    asientosTotales: 48,
    asientosDisp: 15,
    salida: '07:00 PM',
    llegada: '09:00 AM (+1)',
    region: 'este',
    oferta: true,
    imagen: 'https://images.unsplash.com/photo-1506015391300-4802dc74de2e?auto=format&fit=crop&w=800&q=80',
    activa: true,
    caracteristicas: ['Viaje Nocturno Directo', 'Mantas de viaje', 'Asientos semicama', 'Baño']
  },
  {
    id: 'g-107',
    origen: 'Trinidad',
    destino: 'Varadero',
    unidad: 'Yutong #512 Tour Especial',
    precio: 4200,
    moneda: 'CUP',
    asientosTotales: 36,
    asientosDisp: 10,
    salida: '09:00 AM',
    llegada: '02:30 PM',
    region: 'especial',
    oferta: true,
    imagen: 'https://images.unsplash.com/photo-1544620347-c4fd4a3d5957?auto=format&fit=crop&w=800&q=80',
    activa: true,
    caracteristicas: ['Ruta Panorámica Topes de Collantes', 'Guía Turístico', 'Refrigerio incluido']
  }
];

let reservas: Reserva[] = [
  {
    id: 'res-demo-1',
    codigo: 'VP-7842',
    guaguaId: 'g-101',
    nombre: 'La Habana → Varadero',
    pasajeroNombre: 'Juan Carlos Pérez',
    email: 'dgrisel940@gmail.com',
    ci: '91042314582',
    telefono: '+53 5212 3456',
    gestorCodigo: 'CR01',
    fechaViaje: '2026-11-15',
    cantidad: 2,
    precioUnitario: 2500,
    total: 5000,
    moneda: 'CUP',
    estado: 'confirmada',
    creadoEn: '2026-11-09T18:30:00Z'
  }
];

let usuarios: Usuario[] = [
  {
    id: 'u-1',
    nombre: 'Usuario Viajes Perdomo',
    email: 'dgrisel940@gmail.com',
    password: '123',
    gestorCodigo: 'CR01'
  }
];

let valoraciones: Valoracion[] = [
  {
    id: 'val-1',
    usuarioNombre: 'Yoandry Morales',
    estrellas: 5,
    comentario: 'Excelente servicio desde La Habana hasta Santiago. El aire acondicionado perfecto y los choferes muy atentos.',
    fecha: '08 Nov 2026'
  },
  {
    id: 'val-2',
    usuarioNombre: 'Beatriz Delgado',
    estrellas: 5,
    comentario: 'Puntuales en la salida y la guagua Yutong comodísima. Recomiendo reservar con tiempo con el gestor Carlos.',
    fecha: '06 Nov 2026'
  }
];

async function startServer() {
  const app = express();
  const PORT = Number(process.env.PORT) || 3000;

  app.use(express.json());

  // API Gestores
  app.get('/api/gestores', (_req: Request, res: Response) => {
    res.json(gestores);
  });

  // API Auth Register
  app.post('/api/auth/register', (req: Request, res: Response) => {
    const { nombre, email, password, gestorCodigo } = req.body;
    if (!email || !password || !nombre || !gestorCodigo) {
      return res.status(400).json({ error: 'Todos los campos son obligatorios.' });
    }

    const existe = usuarios.find((u) => u.email.toLowerCase() === email.toLowerCase());
    if (existe) {
      return res.status(400).json({ error: 'Ya existe un usuario registrado con este correo.' });
    }

    const nuevoUsuario: Usuario = {
      id: 'u-' + Date.now(),
      nombre,
      email,
      password,
      gestorCodigo
    };
    usuarios.push(nuevoUsuario);

    res.json({
      mensaje: 'Registro completado con éxito',
      usuario: {
        id: nuevoUsuario.id,
        nombre: nuevoUsuario.nombre,
        email: nuevoUsuario.email,
        gestorCodigo: nuevoUsuario.gestorCodigo
      }
    });
  });

  // API Auth Login
  app.post('/api/auth/login', (req: Request, res: Response) => {
    const { email, password } = req.body;
    if (!email || !password) {
      return res.status(400).json({ error: 'Correo y contraseña requeridos.' });
    }

    let user = usuarios.find((u) => u.email.toLowerCase() === email.toLowerCase());
    if (!user) {
      // Auto register for seamless testing experience if credentials match format
      const defaultGestor = gestores[0].usuario;
      user = {
        id: 'u-' + Date.now(),
        nombre: email.split('@')[0],
        email,
        password,
        gestorCodigo: defaultGestor
      };
      usuarios.push(user);
    } else if (user.password && user.password !== password) {
      return res.status(401).json({ error: 'Contraseña incorrecta.' });
    }

    res.json({
      usuario: {
        id: user.id,
        nombre: user.nombre,
        email: user.email,
        gestorCodigo: user.gestorCodigo
      }
    });
  });

  // API Perfil Update
  app.put('/api/perfil', (req: Request, res: Response) => {
    const { email, nombre, password } = req.body;
    if (!email) {
      return res.status(400).json({ error: 'El correo electrónico es requerido.' });
    }

    const user = usuarios.find((u) => u.email.toLowerCase() === email.toLowerCase());
    if (!user) {
      return res.status(404).json({ error: 'Usuario no encontrado.' });
    }

    if (nombre) user.nombre = nombre;
    if (password && password.trim().length > 0) user.password = password;

    res.json({
      mensaje: 'Perfil actualizado exitosamente',
      usuario: {
        id: user.id,
        nombre: user.nombre,
        email: user.email,
        gestorCodigo: user.gestorCodigo
      }
    });
  });

  // API Guaguas
  app.get('/api/guaguas', (_req: Request, res: Response) => {
    res.json(guaguas);
  });

  // API Reservas (GET all or filtered)
  app.get('/api/reservas', (req: Request, res: Response) => {
    const { email } = req.query;
    if (email && typeof email === 'string') {
      const filtradas = reservas.filter((r) => r.email.toLowerCase() === email.toLowerCase());
      return res.json(filtradas);
    }
    res.json(reservas);
  });

  // API Reservas (POST create)
  app.post('/api/reservas', (req: Request, res: Response) => {
    const { nombre, email, gestorCodigo, ci, telefono, guaguaId, fechaViaje, cantidad } = req.body;
    if (!ci || !telefono || !fechaViaje || !guaguaId) {
      return res.status(400).json({ error: 'Faltan datos obligatorios para la reserva.' });
    }

    const guagua = guaguas.find((g) => g.id === guaguaId);
    if (!guagua) {
      return res.status(404).json({ error: 'La guagua seleccionada no existe.' });
    }

    const numPasajeros = Number(cantidad) || 1;
    if (guagua.asientosDisp < numPasajeros) {
      return res.status(400).json({ error: `Solo quedan ${guagua.asientosDisp} asientos disponibles.` });
    }

    // Decrement available seats
    guagua.asientosDisp -= numPasajeros;

    // Generate unique ticket code
    const codigo = `VP-${Math.floor(1000 + Math.random() * 9000)}`;
    const nuevaReserva: Reserva = {
      id: 'res-' + Date.now(),
      codigo,
      guaguaId: guagua.id,
      nombre: `${guagua.origen} → ${guagua.destino}`,
      pasajeroNombre: nombre || 'Pasajero',
      email: email || '',
      ci,
      telefono,
      gestorCodigo: gestorCodigo || 'CR01',
      fechaViaje,
      cantidad: numPasajeros,
      precioUnitario: guagua.precio,
      total: guagua.precio * numPasajeros,
      moneda: guagua.moneda,
      estado: 'confirmada',
      creadoEn: new Date().toISOString()
    };

    reservas.unshift(nuevaReserva);

    res.status(201).json({
      mensaje: '¡Reserva completada con éxito!',
      codigo: nuevaReserva.codigo,
      reserva: nuevaReserva
    });
  });

  // API Reservas (PUT update status / cancel)
  app.put('/api/reservas/:id', (req: Request, res: Response) => {
    const { id } = req.params;
    const { estado } = req.body;

    const reserva = reservas.find((r) => r.id === id || r.codigo === id);
    if (!reserva) {
      return res.status(404).json({ error: 'Reserva no encontrada.' });
    }

    const estadoAnterior = reserva.estado;
    if (estado) {
      reserva.estado = estado;
      // If cancelled and wasn't cancelled before, restore seats
      if (estado === 'cancelada' && estadoAnterior !== 'cancelada') {
        const guagua = guaguas.find((g) => g.id === reserva.guaguaId);
        if (guagua) {
          guagua.asientosDisp = Math.min(guagua.asientosTotales, guagua.asientosDisp + reserva.cantidad);
        }
      }
    }

    res.json({ mensaje: 'Reserva actualizada', reserva });
  });

  // API Valoraciones
  app.get('/api/valoraciones', (_req: Request, res: Response) => {
    res.json(valoraciones);
  });

  app.post('/api/valoraciones', (req: Request, res: Response) => {
    const { usuarioNombre, estrellas, comentario } = req.body;
    if (!comentario) {
      return res.status(400).json({ error: 'El comentario es requerido.' });
    }

    const nuevaVal: Valoracion = {
      id: 'val-' + Date.now(),
      usuarioNombre: usuarioNombre || 'Usuario Anónimo',
      estrellas: Number(estrellas) || 5,
      comentario,
      fecha: new Date().toLocaleDateString('es-ES', { day: '2-digit', month: 'short', year: 'numeric' })
    };

    valoraciones.unshift(nuevaVal);
    res.status(201).json({ mensaje: 'Valoración recibida con éxito', valoracion: nuevaVal });
  });

  // API Download Project ZIP (Ready for GitHub upload & APK compilation)
  app.get('/api/download-zip', (_req: Request, res: Response) => {
    res.setHeader('Content-Type', 'application/zip');
    res.setHeader('Content-Disposition', 'attachment; filename="viajes-perdomo-proyecto.zip"');
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('Content-Transfer-Encoding', 'binary');
    res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate');

    const archive = new ZipArchive({
      zlib: { level: 9 }
    });

    archive.on('error', (err: Error) => {
      console.error('Error generating zip:', err);
      if (!res.headersSent) {
        res.status(500).json({ error: 'Error al generar archivo ZIP' });
      }
    });

    archive.pipe(res);

    archive.glob('**/*', {
      cwd: path.resolve(__dirname),
      ignore: [
        'node_modules/**',
        'dist/**',
        '.git/**',
        '.gradle/**',
        'android/app/build/**',
        'android/.gradle/**',
        'output-apk/**',
        '*.zip',
        '.cache/**',
        '.vite/**',
        'bun.lock'
      ],
      dot: true
    });

    archive.finalize();
  });

  // Dev mode vs Prod mode
  if (process.env.NODE_ENV === 'production') {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  } else {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa'
    });
    app.use(vite.middlewares);
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Viajes Perdomo server corriendo en http://localhost:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Error starting server:', err);
});
