/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Gestor, Guagua, Reserva, Usuario, Valoracion } from './types';
import { api } from './services/api';
import { ReservaModal } from './components/ReservaModal';
import { QRModal } from './components/QRModal';
import { APKModal } from './components/APKModal';
import {
  Menu,
  X,
  Home,
  User,
  Ticket,
  HelpCircle,
  Star,
  Info,
  LogOut,
  Search,
  Calendar,
  Users,
  MapPin,
  Clock,
  Sparkles,
  Smartphone,
  CheckCircle2,
  AlertCircle,
  Download,
  FileArchive,
  Loader2
} from 'lucide-react';

export default function App() {
  // Splash & Auth states
  const [splashVisible, setSplashVisible] = useState(true);
  const [user, setUser] = useState<Usuario | null>(null);
  const [isRegisterMode, setIsRegisterMode] = useState(false);

  // Auth form states
  const [authEmail, setAuthEmail] = useState('');
  const [authPassword, setAuthPassword] = useState('');
  const [authNombre, setAuthNombre] = useState('');
  const [authGestor, setAuthGestor] = useState('');
  const [gestores, setGestores] = useState<Gestor[]>([]);
  const [authLoading, setAuthLoading] = useState(false);

  // App navigation
  const [currentView, setCurrentView] = useState<
    'view-home' | 'view-perfil' | 'view-reservas' | 'view-faq' | 'view-valoracion' | 'view-acerca'
  >('view-home');
  const [sidebarOpen, setSidebarOpen] = useState(false);

  // Data states
  const [guaguas, setGuaguas] = useState<Guagua[]>([]);
  const [reservas, setReservas] = useState<Reserva[]>([]);
  const [valoraciones, setValoraciones] = useState<Valoracion[]>([]);
  const [loadingGuaguas, setLoadingGuaguas] = useState(false);
  const [loadingReservas, setLoadingReservas] = useState(false);

  // Search & Filters
  const [origenFilter, setOrigenFilter] = useState('');
  const [destinoFilter, setDestinoFilter] = useState('');
  const [fechaFilter, setFechaFilter] = useState('');
  const [personasFilter, setPersonasFilter] = useState(1);
  const [regionFilter, setRegionFilter] = useState<'all' | 'este' | 'centro' | 'oeste' | 'especial'>('all');

  // Profile edit states
  const [perfilNombre, setPerfilNombre] = useState('');
  const [perfilPassword, setPerfilPassword] = useState('');
  const [savingPerfil, setSavingPerfil] = useState(false);

  // Valoracion form
  const [valEstrellas, setValEstrellas] = useState(5);
  const [valComentario, setValComentario] = useState('');
  const [submittingVal, setSubmittingVal] = useState(false);

  // Modals
  const [selectedGuagua, setSelectedGuagua] = useState<Guagua | null>(null);
  const [selectedQRReserva, setSelectedQRReserva] = useState<Reserva | null>(null);
  const [apkModalOpen, setApkModalOpen] = useState(false);

  // Toast
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'error' } | null>(null);

  const showToast = (message: string, type: 'success' | 'error' = 'success') => {
    setToast({ message, type });
    setTimeout(() => {
      setToast(null);
    }, 3500);
  };

  // Initial load
  useEffect(() => {
    // 1. Check saved user in localStorage
    try {
      const savedUser = localStorage.getItem('vp_user');
      if (savedUser) {
        const parsed = JSON.parse(savedUser);
        setUser(parsed);
        setPerfilNombre(parsed.nombre);
      }
    } catch {
      // ignore
    }

    // 2. Load gestores list
    api.getGestores().then((data) => {
      setGestores(data);
      if (data.length > 0) {
        setAuthGestor(data[0].usuario);
      }
    });

    // 3. Dismiss splash screen after 1.6s
    const timer = setTimeout(() => {
      setSplashVisible(false);
    }, 1600);

    return () => clearTimeout(timer);
  }, []);

  // Fetch guaguas when user is logged in
  useEffect(() => {
    if (user) {
      loadGuaguas();
      loadReservas();
      loadValoraciones();
    }
  }, [user]);

  const loadGuaguas = async () => {
    try {
      setLoadingGuaguas(true);
      const data = await api.getGuaguas();
      setGuaguas(data);
    } catch {
      showToast('Error al cargar guaguas', 'error');
    } finally {
      setLoadingGuaguas(false);
    }
  };

  const loadReservas = async () => {
    if (!user) return;
    try {
      setLoadingReservas(true);
      const data = await api.getReservas(user.email);
      setReservas(data);
    } catch {
      showToast('Error al cargar reservas', 'error');
    } finally {
      setLoadingReservas(false);
    }
  };

  const loadValoraciones = async () => {
    try {
      const data = await api.getValoraciones();
      setValoraciones(data);
    } catch {
      // ignore
    }
  };

  // Auth handlers
  const handleAuthSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!authEmail.trim() || !authPassword.trim()) {
      showToast('Completa todos los campos obligatorios', 'error');
      return;
    }

    if (isRegisterMode) {
      if (!authNombre.trim()) {
        showToast('El nombre es obligatorio', 'error');
        return;
      }
      if (!authGestor) {
        showToast('Debes seleccionar un gestor asignado', 'error');
        return;
      }
    }

    try {
      setAuthLoading(true);
      let loggedUser: Usuario;
      if (isRegisterMode) {
        loggedUser = await api.register(authNombre.trim(), authEmail.trim(), authPassword.trim(), authGestor);
        showToast(`¡Cuenta creada! Bienvenido, ${loggedUser.nombre}`);
      } else {
        loggedUser = await api.login(authEmail.trim(), authPassword.trim());
        showToast(`Bienvenido, ${loggedUser.nombre}`);
      }

      setUser(loggedUser);
      setPerfilNombre(loggedUser.nombre);
      localStorage.setItem('vp_user', JSON.stringify(loggedUser));
    } catch (err: unknown) {
      showToast(err instanceof Error ? err.message : 'Error de autenticación', 'error');
    } finally {
      setAuthLoading(false);
    }
  };

  const [downloadingZip, setDownloadingZip] = useState(false);

  const handleDownloadZip = async () => {
    try {
      setDownloadingZip(true);
      showToast('Empaquetando código del proyecto en ZIP...');
      await api.downloadProjectZip();
      showToast('¡Descarga lista! Archivo viajes-perdomo-proyecto.zip');
    } catch (err: unknown) {
      showToast('Error al descargar ZIP: ' + (err instanceof Error ? err.message : 'Error'), 'error');
    } finally {
      setDownloadingZip(false);
    }
  };

  const handleGoogleLogin = async () => {
    try {
      setAuthLoading(true);
      const googleUser = await api.login('dgrisel940@gmail.com', '123');
      setUser(googleUser);
      setPerfilNombre(googleUser.nombre);
      localStorage.setItem('vp_user', JSON.stringify(googleUser));
      showToast(`Bienvenido con Gmail, ${googleUser.nombre}`);
    } catch (err: unknown) {
      showToast(err instanceof Error ? err.message : 'Error de inicio con Gmail', 'error');
    } finally {
      setAuthLoading(false);
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('vp_user');
    setUser(null);
    setSidebarOpen(false);
    showToast('Sesión cerrada');
  };

  // Profile update
  const handleSavePerfil = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;
    if (!perfilNombre.trim()) {
      showToast('El nombre no puede estar vacío', 'error');
      return;
    }

    try {
      setSavingPerfil(true);
      const updated = await api.updatePerfil(user.email, perfilNombre.trim(), perfilPassword);
      setUser(updated);
      localStorage.setItem('vp_user', JSON.stringify(updated));
      setPerfilPassword('');
      showToast('¡Datos del perfil actualizados con éxito!');
    } catch (err: unknown) {
      showToast(err instanceof Error ? err.message : 'Error al guardar perfil', 'error');
    } finally {
      setSavingPerfil(false);
    }
  };

  // Reservation handler
  const handleConfirmReservation = async (data: {
    ci: string;
    telefono: string;
    fechaViaje: string;
    cantidad: number;
  }) => {
    if (!user || !selectedGuagua) return;

    const res = await api.createReserva({
      nombre: user.nombre,
      email: user.email,
      gestorCodigo: user.gestorCodigo,
      ci: data.ci,
      telefono: data.telefono,
      guaguaId: selectedGuagua.id,
      fechaViaje: data.fechaViaje,
      cantidad: data.cantidad
    });

    showToast(`¡Reserva exitosa! Código: ${res.codigo}`);
    setSelectedGuagua(null);
    await loadGuaguas();
    await loadReservas();
    // Open QR modal right away for convenience
    setSelectedQRReserva(res.reserva);
  };

  // Cancel reservation
  const handleCancelReserva = async (id: string) => {
    if (!confirm('¿Estás seguro de que deseas cancelar esta reserva? Los asientos volverán a estar disponibles.')) {
      return;
    }
    try {
      await api.cancelReserva(id);
      showToast('Reserva cancelada');
      await loadReservas();
      await loadGuaguas();
    } catch {
      showToast('No se pudo cancelar la reserva', 'error');
    }
  };

  // Valoracion submit
  const handleSendValoracion = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!valComentario.trim()) {
      showToast('Por favor escribe tu comentario', 'error');
      return;
    }
    try {
      setSubmittingVal(true);
      await api.sendValoracion(user?.nombre || 'Pasajero', valEstrellas, valComentario.trim());
      showToast('¡Gracias por tu valoración!');
      setValComentario('');
      await loadValoraciones();
    } catch {
      showToast('Error al enviar valoración', 'error');
    } finally {
      setSubmittingVal(false);
    }
  };

  // Filtered guaguas list
  const filteredGuaguas = guaguas.filter((v) => {
    if (!v.activa) return false;
    if (regionFilter !== 'all' && v.region.toLowerCase() !== regionFilter) return false;
    if (origenFilter && v.origen.toLowerCase() !== origenFilter.toLowerCase()) return false;
    if (destinoFilter && v.destino.toLowerCase() !== destinoFilter.toLowerCase()) return false;
    return true;
  });

  // Cities list for dropdowns
  const ciudades = ['La Habana', 'Varadero', 'Santiago de Cuba', 'Holguín', 'Trinidad', 'Santa Clara', 'Camagüey'];

  // View title helper
  const getViewTitle = () => {
    switch (currentView) {
      case 'view-home':
        return 'Inicio';
      case 'view-perfil':
        return 'Mi Perfil';
      case 'view-reservas':
        return 'Mis Reservas';
      case 'view-faq':
        return 'Preguntas Frecuentes';
      case 'view-valoracion':
        return 'Valorar Agencia';
      case 'view-acerca':
        return 'Acerca de Nosotros';
      default:
        return 'Viajes Perdomo';
    }
  };

  return (
    <div className="min-h-screen bg-[#f8fafc] text-[#0f172a] font-sans antialiased flex flex-col selection:bg-teal-500 selection:text-white">
      {/* 1. Splash Screen */}
      <div
        className={`fixed inset-0 bg-[#115e59] z-[9999] flex flex-col items-center justify-center text-white transition-opacity duration-500 ease-in-out ${
          splashVisible ? 'opacity-100 pointer-events-auto' : 'opacity-0 pointer-events-none'
        }`}
      >
        <div className="text-6xl animate-bounce mb-4">🚌</div>
        <div className="text-3xl font-extrabold tracking-wider">Viajes Perdomo</div>
        <p className="text-teal-200 text-sm mt-2 font-medium">Transporte interprovincial en Cuba</p>
        <div className="mt-8 flex items-center gap-1.5">
          <span className="w-2.5 h-2.5 bg-amber-400 rounded-full animate-ping"></span>
          <span className="text-xs text-teal-300 font-mono">Cargando rutas y guaguas...</span>
        </div>
      </div>

      {/* 2. Login / Register Screen (When not authenticated) */}
      {!user && (
        <div className="min-h-screen bg-[#f8fafc] flex flex-col items-center justify-center p-4">
          <div className="bg-white rounded-2xl p-6 sm:p-8 w-full max-w-md shadow-xl border border-slate-100 animate-in fade-in zoom-in-95 duration-300">
            <div className="text-center mb-6">
              <div className="inline-flex p-3 bg-teal-50 rounded-2xl text-4xl mb-2">🚌</div>
              <h2 className="text-2xl font-extrabold text-[#0f766e]">
                {isRegisterMode ? 'Crear Cuenta' : 'Iniciar Sesión'}
              </h2>
              <p className="text-xs text-slate-500 mt-1">Viajes Perdomo • Guaguas Yutong</p>
            </div>

            <form onSubmit={handleAuthSubmit} className="space-y-4">
              {isRegisterMode && (
                <div>
                  <label className="block text-xs font-bold text-slate-600 mb-1">Nombre completo *</label>
                  <input
                    type="text"
                    required
                    placeholder="Tu nombre y apellidos"
                    value={authNombre}
                    onChange={(e) => setAuthNombre(e.target.value)}
                    className="w-full px-3.5 py-2.5 text-sm border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#0f766e] bg-slate-50/50"
                  />
                </div>
              )}

              <div>
                <label className="block text-xs font-bold text-slate-600 mb-1">Correo electrónico *</label>
                <input
                  type="email"
                  required
                  placeholder="correo@ejemplo.com"
                  value={authEmail}
                  onChange={(e) => setAuthEmail(e.target.value)}
                  className="w-full px-3.5 py-2.5 text-sm border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#0f766e] bg-slate-50/50"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-600 mb-1">Contraseña *</label>
                <input
                  type="password"
                  required
                  placeholder="••••••••"
                  value={authPassword}
                  onChange={(e) => setAuthPassword(e.target.value)}
                  className="w-full px-3.5 py-2.5 text-sm border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#0f766e] bg-slate-50/50"
                />
              </div>

              {isRegisterMode && (
                <div>
                  <label className="block text-xs font-bold text-slate-600 mb-1">
                    Gestor que te atendió (Obligatorio) *
                  </label>
                  <select
                    value={authGestor}
                    onChange={(e) => setAuthGestor(e.target.value)}
                    required
                    className="w-full px-3.5 py-2.5 text-sm border-2 border-amber-400 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#0f766e] bg-white text-slate-800"
                  >
                    <option value="">-- Seleccione un gestor --</option>
                    {gestores.map((g) => (
                      <option key={g.usuario} value={g.usuario}>
                        {g.nombre} ({g.usuario}) - {g.agencia}
                      </option>
                    ))}
                  </select>
                </div>
              )}

              <button
                type="submit"
                disabled={authLoading}
                className="w-full bg-[#0f766e] hover:bg-[#115e59] text-white py-3 rounded-xl font-bold text-sm shadow-md transition-all active:scale-[0.99] cursor-pointer mt-2"
              >
                {authLoading ? 'Verificando...' : isRegisterMode ? 'Registrarse' : 'Entrar'}
              </button>
            </form>

            <div className="relative my-5">
              <div className="absolute inset-0 flex items-center">
                <div className="w-full border-t border-slate-200"></div>
              </div>
              <div className="relative flex justify-center text-xs uppercase">
                <span className="bg-white px-3 text-slate-400 font-semibold">o continuar con</span>
              </div>
            </div>

            <button
              onClick={handleGoogleLogin}
              type="button"
              className="w-full bg-white hover:bg-slate-50 text-slate-700 border border-slate-300 py-2.5 px-4 rounded-xl font-semibold text-sm flex items-center justify-center gap-2.5 shadow-2xs transition-colors cursor-pointer"
            >
              <img
                src="https://upload.wikimedia.org/wikipedia/commons/5/53/Google_%22G%22_Logo.svg"
                alt="Google"
                className="w-5 h-5"
              />
              <span>Acceder con Gmail</span>
            </button>

            <div className="text-center mt-6">
              <button
                onClick={() => setIsRegisterMode(!isRegisterMode)}
                className="text-xs text-[#0f766e] hover:text-[#115e59] font-bold underline transition cursor-pointer"
              >
                {isRegisterMode ? '¿Ya tienes cuenta? Inicia sesión aquí' : '¿No tienes cuenta? Regístrate aquí'}
              </button>
            </div>

            <div className="mt-6 pt-5 border-t border-slate-100">
              <button
                type="button"
                onClick={handleDownloadZip}
                disabled={downloadingZip}
                className="w-full bg-amber-500 hover:bg-amber-600 disabled:bg-amber-300 text-slate-950 font-black py-2.5 px-3 rounded-xl text-xs flex items-center justify-center gap-2 shadow-sm transition active:scale-95 cursor-pointer"
                title="Descargar código completo del proyecto comprimido en ZIP"
              >
                {downloadingZip ? (
                  <>
                    <Loader2 className="w-4 h-4 text-slate-950 animate-spin" />
                    <span>Empaquetando ZIP...</span>
                  </>
                ) : (
                  <>
                    <Download className="w-4 h-4 text-slate-950" />
                    <span>Descargar Proyecto (.ZIP)</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 3. Main Authenticated Application */}
      {user && (
        <div className="flex-1 flex flex-row relative min-h-screen">
          {/* Mobile Sidebar Overlay */}
          <div
            onClick={() => setSidebarOpen(false)}
            className={`fixed inset-0 bg-black/50 z-[4000] transition-opacity duration-300 md:hidden ${
              sidebarOpen ? 'opacity-100 pointer-events-auto' : 'opacity-0 pointer-events-none'
            }`}
          />

          {/* Sidebar Drawer */}
          <aside
            className={`fixed top-0 left-0 bottom-0 w-64 bg-[#115e59] text-white z-[5000] flex flex-col shadow-2xl transition-transform duration-300 ease-in-out md:translate-x-0 ${
              sidebarOpen ? 'translate-x-0' : '-translate-x-full'
            }`}
          >
            {/* Sidebar Header */}
            <div className="p-5 border-b border-white/10 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <span className="text-3xl">🚌</span>
                <div>
                  <h2 className="font-extrabold text-lg leading-tight">Viajes Perdomo</h2>
                  <p className="text-[11px] text-teal-200">Guaguas Interprovinciales</p>
                </div>
              </div>
              <button
                onClick={() => setSidebarOpen(false)}
                className="md:hidden text-white/80 hover:text-white p-1 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Sidebar Menu Items */}
            <ul className="py-3 flex-1 overflow-y-auto space-y-1 px-2 text-sm font-medium">
              <li>
                <button
                  onClick={() => {
                    setCurrentView('view-home');
                    setSidebarOpen(false);
                  }}
                  className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all cursor-pointer ${
                    currentView === 'view-home'
                      ? 'bg-white/20 text-white font-bold border-l-4 border-amber-400'
                      : 'text-teal-100 hover:bg-white/10'
                  }`}
                >
                  <Home className="w-4 h-4 text-amber-400" />
                  <span>Inicio</span>
                </button>
              </li>

              <li>
                <button
                  onClick={() => {
                    setCurrentView('view-perfil');
                    setSidebarOpen(false);
                  }}
                  className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all cursor-pointer ${
                    currentView === 'view-perfil'
                      ? 'bg-white/20 text-white font-bold border-l-4 border-amber-400'
                      : 'text-teal-100 hover:bg-white/10'
                  }`}
                >
                  <User className="w-4 h-4 text-amber-400" />
                  <span>Mi Perfil</span>
                </button>
              </li>

              <li>
                <button
                  onClick={() => {
                    setCurrentView('view-reservas');
                    loadReservas();
                    setSidebarOpen(false);
                  }}
                  className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all cursor-pointer ${
                    currentView === 'view-reservas'
                      ? 'bg-white/20 text-white font-bold border-l-4 border-amber-400'
                      : 'text-teal-100 hover:bg-white/10'
                  }`}
                >
                  <Ticket className="w-4 h-4 text-amber-400" />
                  <span>Mis Reservas</span>
                  {reservas.length > 0 && (
                    <span className="ml-auto bg-amber-500 text-white text-[10px] font-extrabold px-2 py-0.5 rounded-full">
                      {reservas.length}
                    </span>
                  )}
                </button>
              </li>

              <li>
                <button
                  onClick={() => {
                    setCurrentView('view-faq');
                    setSidebarOpen(false);
                  }}
                  className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all cursor-pointer ${
                    currentView === 'view-faq'
                      ? 'bg-white/20 text-white font-bold border-l-4 border-amber-400'
                      : 'text-teal-100 hover:bg-white/10'
                  }`}
                >
                  <HelpCircle className="w-4 h-4 text-amber-400" />
                  <span>Preguntas Frecuentes</span>
                </button>
              </li>

              <li>
                <button
                  onClick={() => {
                    setCurrentView('view-valoracion');
                    setSidebarOpen(false);
                  }}
                  className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all cursor-pointer ${
                    currentView === 'view-valoracion'
                      ? 'bg-white/20 text-white font-bold border-l-4 border-amber-400'
                      : 'text-teal-100 hover:bg-white/10'
                  }`}
                >
                  <Star className="w-4 h-4 text-amber-400" />
                  <span>Valorar Agencia</span>
                </button>
              </li>

              <li>
                <button
                  onClick={() => {
                    setCurrentView('view-acerca');
                    setSidebarOpen(false);
                  }}
                  className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all cursor-pointer ${
                    currentView === 'view-acerca'
                      ? 'bg-white/20 text-white font-bold border-l-4 border-amber-400'
                      : 'text-teal-100 hover:bg-white/10'
                  }`}
                >
                  <Info className="w-4 h-4 text-amber-400" />
                  <span>Acerca de Nosotros</span>
                </button>
              </li>

              <li className="pt-2">
                <button
                  type="button"
                  onClick={handleDownloadZip}
                  disabled={downloadingZip}
                  className="w-full flex items-center gap-3 px-4 py-2.5 rounded-xl text-amber-950 hover:bg-amber-300 disabled:bg-amber-300/80 font-extrabold text-xs bg-amber-400 transition-all shadow-md cursor-pointer"
                >
                  {downloadingZip ? (
                    <>
                      <Loader2 className="w-4 h-4 text-slate-950 animate-spin" />
                      <span>Empaquetando ZIP...</span>
                    </>
                  ) : (
                    <>
                      <Download className="w-4 h-4 text-slate-950" />
                      <span>Descargar ZIP del Proyecto</span>
                    </>
                  )}
                </button>
              </li>

              <li>
                <button
                  onClick={() => {
                    setApkModalOpen(true);
                    setSidebarOpen(false);
                  }}
                  className="w-full flex items-center gap-3 px-4 py-2 rounded-xl text-amber-300 hover:bg-white/10 font-bold text-xs bg-white/5 border border-amber-400/30 transition-all cursor-pointer"
                >
                  <Smartphone className="w-4 h-4 text-amber-400" />
                  <span>Compilar APK (GitHub)</span>
                </button>
              </li>
            </ul>

            {/* Sidebar Footer with Logout */}
            <div className="p-3 border-t border-white/10">
              <button
                onClick={handleLogout}
                className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-rose-300 hover:bg-rose-900/30 font-semibold transition-colors cursor-pointer"
              >
                <LogOut className="w-4 h-4" />
                <span>Cerrar Sesión</span>
              </button>
            </div>
          </aside>

          {/* Main Content Area */}
          <div className="flex-1 flex flex-col w-full md:ml-64 min-h-screen">
            {/* Top Navigation Bar */}
            <header className="bg-[#0f766e] text-white px-4 py-3.5 flex items-center justify-between shadow-md sticky top-0 z-30">
              <div className="flex items-center gap-3">
                <button
                  onClick={() => setSidebarOpen(true)}
                  className="md:hidden p-1.5 rounded-lg hover:bg-white/10 transition-colors text-white"
                  title="Abrir Menú"
                >
                  <Menu className="w-6 h-6" />
                </button>
                <h1 className="font-extrabold text-lg tracking-tight">{getViewTitle()}</h1>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={handleDownloadZip}
                  disabled={downloadingZip}
                  className="flex items-center gap-1.5 bg-amber-400 hover:bg-amber-300 disabled:bg-amber-300/80 text-slate-950 px-3 py-1.5 rounded-xl text-xs font-black shadow-md transition-all active:scale-95 cursor-pointer"
                  title="Descargar código completo del proyecto comprimido en ZIP"
                >
                  {downloadingZip ? (
                    <>
                      <Loader2 className="w-4 h-4 text-slate-950 animate-spin" />
                      <span>Descargando...</span>
                    </>
                  ) : (
                    <>
                      <Download className="w-4 h-4 text-slate-950" />
                      <span>Descargar ZIP</span>
                    </>
                  )}
                </button>

                <button
                  onClick={() => setApkModalOpen(true)}
                  className="hidden sm:flex items-center gap-1.5 bg-teal-800 hover:bg-teal-900 text-teal-100 border border-teal-600/50 px-2.5 py-1.5 rounded-xl text-xs font-bold transition shadow-xs cursor-pointer"
                  title="Exportar a Android APK"
                >
                  <Smartphone className="w-3.5 h-3.5 text-amber-400" />
                  <span>Exportar APK</span>
                </button>

                <div className="text-right flex items-center gap-2">
                  <div className="w-8 h-8 rounded-full bg-teal-800 flex items-center justify-center font-bold text-amber-300 text-xs border border-white/20">
                    {user.nombre.charAt(0).toUpperCase()}
                  </div>
                  <span className="text-xs font-semibold hidden sm:inline-block">Hola, {user.nombre}</span>
                </div>
              </div>
            </header>

            {/* Main Views Container */}
            <main className="flex-1 p-4 sm:p-6 max-w-7xl mx-auto w-full">
              {/* VIEW 1: HOME */}
              {currentView === 'view-home' && (
                <div className="space-y-6 animate-in fade-in duration-300">
                  {/* Hero Banner */}
                  <div className="bg-[#115e59] text-white rounded-3xl p-6 sm:p-10 text-center relative overflow-hidden shadow-lg">
                    <div className="relative z-10 max-w-xl mx-auto">
                      <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-white/10 rounded-full text-xs font-semibold text-teal-200 mb-3 backdrop-blur-xs">
                        <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                        <span>Flota Yutong 2026 de Máximo Confort</span>
                      </div>
                      <h1 className="text-2xl sm:text-4xl font-extrabold tracking-tight">Viaja cómodo por Cuba</h1>
                      <p className="text-teal-100 text-sm sm:text-base mt-2">
                        Guaguas Yutong climatizadas con A/C doble turbina, WiFi y asientos reclinables.
                      </p>
                    </div>
                  </div>

                  {/* Search Box */}
                  <div className="bg-white rounded-2xl p-4 sm:p-6 shadow-xl border border-slate-100 -mt-8 sm:-mt-10 relative z-20 max-w-4xl mx-auto">
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5">
                      <div>
                        <label className="block text-xs font-bold text-slate-500 mb-1 flex items-center gap-1">
                          <MapPin className="w-3.5 h-3.5 text-[#0f766e]" />
                          Origen
                        </label>
                        <select
                          value={origenFilter}
                          onChange={(e) => setOrigenFilter(e.target.value)}
                          className="w-full p-2.5 text-sm border border-slate-200 rounded-xl bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#0f766e]"
                        >
                          <option value="">Cualquiera</option>
                          {ciudades.map((c) => (
                            <option key={`orig-${c}`} value={c}>
                              {c}
                            </option>
                          ))}
                        </select>
                      </div>

                      <div>
                        <label className="block text-xs font-bold text-slate-500 mb-1 flex items-center gap-1">
                          <MapPin className="w-3.5 h-3.5 text-amber-500" />
                          Destino
                        </label>
                        <select
                          value={destinoFilter}
                          onChange={(e) => setDestinoFilter(e.target.value)}
                          className="w-full p-2.5 text-sm border border-slate-200 rounded-xl bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#0f766e]"
                        >
                          <option value="">Cualquiera</option>
                          {ciudades.map((c) => (
                            <option key={`dest-${c}`} value={c}>
                              {c}
                            </option>
                          ))}
                        </select>
                      </div>

                      <div>
                        <label className="block text-xs font-bold text-slate-500 mb-1 flex items-center gap-1">
                          <Calendar className="w-3.5 h-3.5 text-[#0f766e]" />
                          Fecha
                        </label>
                        <input
                          type="date"
                          value={fechaFilter}
                          onChange={(e) => setFechaFilter(e.target.value)}
                          className="w-full p-2.5 text-sm border border-slate-200 rounded-xl bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#0f766e]"
                        />
                      </div>

                      <div>
                        <label className="block text-xs font-bold text-slate-500 mb-1 flex items-center gap-1">
                          <Users className="w-3.5 h-3.5 text-[#0f766e]" />
                          Personas
                        </label>
                        <input
                          type="number"
                          min={1}
                          max={10}
                          value={personasFilter}
                          onChange={(e) => setPersonasFilter(Math.max(1, parseInt(e.target.value) || 1))}
                          className="w-full p-2.5 text-sm border border-slate-200 rounded-xl bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#0f766e]"
                        />
                      </div>
                    </div>

                    <div className="mt-4 flex justify-end">
                      <button
                        onClick={loadGuaguas}
                        className="w-full sm:w-auto bg-[#f59e0b] hover:bg-amber-600 text-slate-950 font-extrabold px-6 py-2.5 rounded-xl shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer"
                      >
                        <Search className="w-4 h-4" />
                        <span>Buscar Viajes</span>
                      </button>
                    </div>
                  </div>

                  {/* Filter Chips */}
                  <div className="flex gap-2 overflow-x-auto pb-1 scrollbar-none">
                    {(
                      [
                        { id: 'all', label: 'Todas las Rutas' },
                        { id: 'este', label: '🛣️ Rutas Este' },
                        { id: 'centro', label: '🛣️ Rutas Centro' },
                        { id: 'oeste', label: '🛣️ Rutas Oeste' },
                        { id: 'especial', label: '⭐ Tours Especiales' }
                      ] as const
                    ).map((chip) => (
                      <button
                        key={chip.id}
                        onClick={() => setRegionFilter(chip.id)}
                        className={`px-4 py-2 rounded-full text-xs font-bold transition-all whitespace-nowrap cursor-pointer ${
                          regionFilter === chip.id
                            ? 'bg-[#0f766e] text-white shadow-md'
                            : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'
                        }`}
                      >
                        {chip.label}
                      </button>
                    ))}
                  </div>

                  {/* Guaguas Grid */}
                  {loadingGuaguas ? (
                    <div className="text-center py-12 text-slate-400">
                      <div className="inline-block animate-spin text-3xl mb-2">🚌</div>
                      <p className="text-sm">Consultando disponibilidad de guaguas...</p>
                    </div>
                  ) : filteredGuaguas.length === 0 ? (
                    <div className="bg-white rounded-2xl p-10 text-center border border-slate-200">
                      <p className="text-slate-500 font-medium">
                        No se encontraron guaguas disponibles para los filtros seleccionados.
                      </p>
                      <button
                        onClick={() => {
                          setOrigenFilter('');
                          setDestinoFilter('');
                          setRegionFilter('all');
                        }}
                        className="mt-3 text-xs text-[#0f766e] font-bold underline cursor-pointer"
                      >
                        Restablecer filtros
                      </button>
                    </div>
                  ) : (
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
                      {filteredGuaguas.map((v) => (
                        <article
                          key={v.id}
                          className="bg-white rounded-2xl overflow-hidden shadow-sm hover:shadow-xl transition-all duration-300 border border-slate-100 flex flex-col"
                        >
                          {/* Image & Badges */}
                          <div
                            className="h-44 bg-cover bg-center relative p-3 flex flex-col justify-between"
                            style={{ backgroundImage: `url('${v.imagen}')` }}
                          >
                            <div className="flex justify-between items-start">
                              {v.oferta ? (
                                <span className="bg-rose-600 text-white text-[11px] font-black px-2.5 py-0.5 rounded-full shadow-md uppercase tracking-wider">
                                  Oferta
                                </span>
                              ) : (
                                <span></span>
                              )}
                              <span className="bg-[#f59e0b] text-slate-950 font-black text-sm px-3 py-1 rounded-full shadow-md">
                                {v.precio} {v.moneda}
                              </span>
                            </div>

                            <div>
                              <span className="inline-flex items-center gap-1 bg-black/75 backdrop-blur-xs text-white text-xs font-semibold px-2.5 py-1 rounded-lg">
                                <span>🚌</span> {v.unidad}
                              </span>
                            </div>
                          </div>

                          {/* Body */}
                          <div className="p-4 flex-1 flex flex-col justify-between">
                            <div>
                              <div className="text-base font-extrabold text-slate-900 mb-2">
                                {v.origen} → {v.destino}
                              </div>

                              <div className="flex flex-wrap gap-2 text-xs text-slate-600 mb-3">
                                <span className="bg-slate-100 px-2 py-1 rounded-md font-medium flex items-center gap-1">
                                  <span>🪑</span> {v.asientosDisp} disp.
                                </span>
                                <span className="bg-slate-100 px-2 py-1 rounded-md font-medium flex items-center gap-1">
                                  <Clock className="w-3 h-3 text-[#0f766e]" /> {v.salida}
                                </span>
                                {v.region && (
                                  <span className="bg-teal-50 text-teal-800 px-2 py-1 rounded-md font-medium capitalize">
                                    {v.region}
                                  </span>
                                )}
                              </div>

                              {v.caracteristicas && v.caracteristicas.length > 0 && (
                                <div className="text-[11px] text-slate-500 mb-3 flex flex-wrap gap-1">
                                  {v.caracteristicas.map((c, i) => (
                                    <span key={i} className="bg-slate-50 border border-slate-200 px-1.5 py-0.5 rounded">
                                      ✓ {c}
                                    </span>
                                  ))}
                                </div>
                              )}
                            </div>

                            <button
                              onClick={() => setSelectedGuagua(v)}
                              disabled={v.asientosDisp <= 0}
                              className={`w-full py-2.5 px-4 rounded-xl font-bold text-sm shadow-xs transition-all cursor-pointer ${
                                v.asientosDisp > 0
                                  ? 'bg-[#0f766e] hover:bg-[#115e59] text-white active:scale-[0.99]'
                                  : 'bg-slate-200 text-slate-400 cursor-not-allowed'
                              }`}
                            >
                              {v.asientosDisp > 0 ? 'Reservar Pasaje' : 'Asientos Agotados'}
                            </button>
                          </div>
                        </article>
                      ))}
                    </div>
                  )}
                </div>
              )}

              {/* VIEW 2: PERFIL */}
              {currentView === 'view-perfil' && (
                <div className="max-w-xl mx-auto bg-white rounded-2xl p-6 sm:p-8 shadow-sm border border-slate-100 animate-in fade-in duration-300">
                  <div className="flex items-center gap-3 mb-6 border-b border-slate-100 pb-4">
                    <div className="w-12 h-12 bg-teal-50 rounded-2xl flex items-center justify-center text-[#0f766e]">
                      <User className="w-6 h-6" />
                    </div>
                    <div>
                      <h2 className="text-xl font-extrabold text-[#0f766e]">Editar mis datos</h2>
                      <p className="text-xs text-slate-500">Actualiza tu información de contacto</p>
                    </div>
                  </div>

                  <form onSubmit={handleSavePerfil} className="space-y-4">
                    <div>
                      <label className="block text-xs font-bold text-slate-600 mb-1">Nombre completo *</label>
                      <input
                        type="text"
                        required
                        value={perfilNombre}
                        onChange={(e) => setPerfilNombre(e.target.value)}
                        className="w-full px-3.5 py-2.5 text-sm border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#0f766e]"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-400 mb-1">
                        Correo electrónico (No editable)
                      </label>
                      <input
                        type="email"
                        disabled
                        value={user.email}
                        className="w-full px-3.5 py-2.5 text-sm border border-slate-200 rounded-xl bg-slate-100 text-slate-500 cursor-not-allowed"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-600 mb-1">
                        Gestor asignado a tu cuenta
                      </label>
                      <input
                        type="text"
                        disabled
                        value={user.gestorCodigo}
                        className="w-full px-3.5 py-2.5 text-sm border border-slate-200 rounded-xl bg-slate-100 text-slate-600 cursor-not-allowed font-mono"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-600 mb-1">
                        Nueva Contraseña (dejar en blanco para no cambiar)
                      </label>
                      <input
                        type="password"
                        placeholder="••••••••"
                        value={perfilPassword}
                        onChange={(e) => setPerfilPassword(e.target.value)}
                        className="w-full px-3.5 py-2.5 text-sm border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#0f766e]"
                      />
                    </div>

                    <button
                      type="submit"
                      disabled={savingPerfil}
                      className="w-full bg-[#0f766e] hover:bg-[#115e59] text-white py-3 rounded-xl font-bold text-sm shadow-md transition-all active:scale-[0.99] cursor-pointer mt-4"
                    >
                      {savingPerfil ? 'Guardando cambios...' : 'Guardar Cambios'}
                    </button>
                  </form>
                </div>
              )}

              {/* VIEW 3: RESERVAS */}
              {currentView === 'view-reservas' && (
                <div className="space-y-4 animate-in fade-in duration-300 max-w-4xl mx-auto">
                  <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2 mb-2">
                    <div>
                      <h2 className="text-xl font-extrabold text-[#0f766e]">Mis Reservas</h2>
                      <p className="text-xs text-slate-500">Consulta tus boletos, estado y códigos QR para abordar</p>
                    </div>

                    <button
                      onClick={loadReservas}
                      className="text-xs bg-slate-100 hover:bg-slate-200 px-3 py-1.5 rounded-lg font-bold text-slate-700 transition cursor-pointer"
                    >
                      Actualizar Lista
                    </button>
                  </div>

                  {loadingReservas ? (
                    <div className="text-center py-12 text-slate-400">
                      <p className="text-sm">Cargando tus reservas...</p>
                    </div>
                  ) : reservas.length === 0 ? (
                    <div className="bg-white rounded-2xl p-8 text-center border border-slate-200 shadow-sm">
                      <div className="text-4xl mb-3">🎫</div>
                      <h3 className="font-bold text-slate-800 text-base">No tienes reservas realizadas aún</h3>
                      <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
                        Explora las salidas disponibles de La Habana a Varadero, Santiago de Cuba, Trinidad y más ciudades.
                      </p>
                      <button
                        onClick={() => setCurrentView('view-home')}
                        className="mt-4 bg-[#0f766e] text-white px-5 py-2.5 rounded-xl text-xs font-bold shadow-sm hover:bg-[#115e59] transition cursor-pointer"
                      >
                        Buscar Viajes Disponibles
                      </button>
                    </div>
                  ) : (
                    <div className="space-y-3.5">
                      {reservas.map((r) => {
                        const statusColors: Record<string, string> = {
                          pendiente: 'bg-amber-100 text-amber-800 border-amber-200',
                          confirmada: 'bg-emerald-100 text-emerald-800 border-emerald-200',
                          cancelada: 'bg-rose-100 text-rose-800 border-rose-200',
                          completada: 'bg-blue-100 text-blue-800 border-blue-200'
                        };

                        return (
                          <div
                            key={r.id}
                            className="bg-white rounded-2xl p-4 sm:p-5 shadow-sm border border-slate-200 border-l-4 border-l-[#f59e0b] hover:shadow-md transition-shadow"
                          >
                            <div className="flex flex-wrap justify-between items-center gap-2 mb-3 pb-2 border-b border-slate-100">
                              <div className="flex items-center gap-2">
                                <span className="font-mono font-extrabold text-[#0f766e] text-base">
                                  Boleto {r.codigo}
                                </span>
                              </div>
                              <span
                                className={`text-xs px-2.5 py-0.5 rounded-full font-bold uppercase border ${
                                  statusColors[r.estado] || 'bg-slate-100 text-slate-800'
                                }`}
                              >
                                {r.estado}
                              </span>
                            </div>

                            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs text-slate-600 mb-4">
                              <div>
                                <span className="font-semibold text-slate-800">Ruta:</span> {r.nombre}
                              </div>
                              <div>
                                <span className="font-semibold text-slate-800">Fecha de viaje:</span> {r.fechaViaje}
                              </div>
                              <div>
                                <span className="font-semibold text-slate-800">Pasajeros:</span> {r.cantidad}
                              </div>
                              <div>
                                <span className="font-semibold text-slate-800">Total a pagar:</span>{' '}
                                <strong className="text-slate-900 font-extrabold">
                                  {r.total} {r.moneda}
                                </strong>
                              </div>
                              <div>
                                <span className="font-semibold text-slate-800">CI Pasajero:</span> {r.ci}
                              </div>
                              <div>
                                <span className="font-semibold text-slate-800">Gestor asignado:</span> {r.gestorCodigo}
                              </div>
                            </div>

                            <div className="flex flex-wrap gap-2 pt-1 border-t border-slate-100">
                              {r.estado !== 'cancelada' && r.estado !== 'completada' && (
                                <button
                                  onClick={() => handleCancelReserva(r.id)}
                                  className="px-4 py-2 border border-rose-300 text-rose-700 hover:bg-rose-50 rounded-xl font-bold text-xs transition cursor-pointer"
                                >
                                  Cancelar Reserva
                                </button>
                              )}

                              {r.estado !== 'cancelada' && (
                                <button
                                  onClick={() => setSelectedQRReserva(r)}
                                  className="flex-1 sm:flex-none flex items-center justify-center gap-1.5 bg-[#0f766e] hover:bg-[#115e59] text-white px-4 py-2 rounded-xl font-bold text-xs transition shadow-xs cursor-pointer"
                                >
                                  <span>📱 Mostrar QR para Abordar</span>
                                </button>
                              )}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>
              )}

              {/* VIEW 4: FAQ */}
              {currentView === 'view-faq' && (
                <div className="max-w-3xl mx-auto bg-white rounded-2xl p-6 sm:p-8 shadow-sm border border-slate-100 animate-in fade-in duration-300">
                  <div className="flex items-center gap-3 mb-6 border-b border-slate-100 pb-4">
                    <div className="w-12 h-12 bg-teal-50 rounded-2xl flex items-center justify-center text-[#0f766e]">
                      <HelpCircle className="w-6 h-6" />
                    </div>
                    <div>
                      <h2 className="text-xl font-extrabold text-[#0f766e]">Preguntas Frecuentes</h2>
                      <p className="text-xs text-slate-500">Respuestas rápidas para tu viaje interprovincial</p>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <div className="p-4 rounded-xl bg-slate-50 border border-slate-100">
                      <h4 className="font-bold text-[#0f766e] text-sm mb-1">¿Cómo puedo pagar mi reserva?</h4>
                      <p className="text-xs text-slate-600 leading-relaxed">
                        El pago se realiza directamente al momento de abordar la guagua, en efectivo (CUP) o mediante transferencia electrónica EnZona / Transfermóvil con tu gestor designado.
                      </p>
                    </div>

                    <div className="p-4 rounded-xl bg-slate-50 border border-slate-100">
                      <h4 className="font-bold text-[#0f766e] text-sm mb-1">¿Puedo cancelar mi reserva?</h4>
                      <p className="text-xs text-slate-600 leading-relaxed">
                        Sí, desde la sección &quot;Mis Reservas&quot; puedes cancelar tu viaje en cualquier momento. Los asientos volverán a estar disponibles automáticamente en el sistema.
                      </p>
                    </div>

                    <div className="p-4 rounded-xl bg-slate-50 border border-slate-100">
                      <h4 className="font-bold text-[#0f766e] text-sm mb-1">¿Cuánto equipaje puedo llevar?</h4>
                      <p className="text-xs text-slate-600 leading-relaxed">
                        Cada pasajero tiene derecho a una maleta grande en el maletero inferior del autobús y un bolso o mochila de mano en cabina sin costo adicional.
                      </p>
                    </div>

                    <div className="p-4 rounded-xl bg-slate-50 border border-slate-100">
                      <h4 className="font-bold text-[#0f766e] text-sm mb-1">
                        ¿Qué debo mostrar al momento de abordar?
                      </h4>
                      <p className="text-xs text-slate-600 leading-relaxed">
                        Debes presentar tu Carnet de Identidad (CI) original y mostrar en la pantalla de tu móvil el código QR o código de boleto digital generado en la app.
                      </p>
                    </div>

                    <div className="p-4 rounded-xl bg-slate-50 border border-slate-100">
                      <h4 className="font-bold text-[#0f766e] text-sm mb-1">
                        ¿Con qué tiempo de anticipación debo llegar?
                      </h4>
                      <p className="text-xs text-slate-600 leading-relaxed">
                        Te recomendamos presentarte en el punto de salida al menos 30 a 45 minutos antes de la hora fijada para el chequeo de equipaje y asignación de asientos.
                      </p>
                    </div>
                  </div>
                </div>
              )}

              {/* VIEW 5: VALORACION */}
              {currentView === 'view-valoracion' && (
                <div className="max-w-2xl mx-auto space-y-6 animate-in fade-in duration-300">
                  <div className="bg-white rounded-2xl p-6 sm:p-8 shadow-sm border border-slate-100">
                    <div className="flex items-center gap-3 mb-4">
                      <div className="w-12 h-12 bg-amber-50 rounded-2xl flex items-center justify-center text-amber-500">
                        <Star className="w-6 h-6 fill-amber-400" />
                      </div>
                      <div>
                        <h2 className="text-xl font-extrabold text-[#0f766e]">Deja tu Valoración</h2>
                        <p className="text-xs text-slate-500">Tu opinión nos ayuda a mejorar nuestro servicio</p>
                      </div>
                    </div>

                    <form onSubmit={handleSendValoracion} className="space-y-4">
                      <div>
                        <label className="block text-xs font-bold text-slate-600 mb-1">Calificación en estrellas</label>
                        <div className="flex items-center gap-2 py-1">
                          {[1, 2, 3, 4, 5].map((star) => (
                            <button
                              key={star}
                              type="button"
                              onClick={() => setValEstrellas(star)}
                              className="text-2xl hover:scale-110 transition cursor-pointer"
                            >
                              <Star
                                className={`w-8 h-8 ${
                                  star <= valEstrellas
                                    ? 'text-amber-400 fill-amber-400'
                                    : 'text-slate-300 fill-slate-100'
                                }`}
                              />
                            </button>
                          ))}
                          <span className="text-xs font-bold text-slate-700 ml-2">
                            {valEstrellas === 5
                              ? '⭐⭐⭐⭐⭐ Excelente'
                              : valEstrellas === 4
                              ? '⭐⭐⭐⭐ Muy bueno'
                              : valEstrellas === 3
                              ? '⭐⭐⭐ Bueno'
                              : valEstrellas === 2
                              ? '⭐⭐ Regular'
                              : '⭐ Malo'}
                          </span>
                        </div>
                      </div>

                      <div>
                        <label className="block text-xs font-bold text-slate-600 mb-1">Tu comentario *</label>
                        <textarea
                          rows={4}
                          required
                          value={valComentario}
                          onChange={(e) => setValComentario(e.target.value)}
                          placeholder="Cuéntanos tu experiencia con el viaje, la guagua Yutong o el gestor..."
                          className="w-full px-3.5 py-2.5 text-sm border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#0f766e]"
                        />
                      </div>

                      <button
                        type="submit"
                        disabled={submittingVal}
                        className="w-full bg-[#0f766e] hover:bg-[#115e59] text-white py-3 rounded-xl font-bold text-sm shadow-md transition-all active:scale-[0.99] cursor-pointer"
                      >
                        {submittingVal ? 'Enviando...' : 'Enviar Valoración'}
                      </button>
                    </form>
                  </div>

                  {/* Recent valoraciones */}
                  <div className="bg-white rounded-2xl p-6 shadow-sm border border-slate-100">
                    <h3 className="font-extrabold text-slate-900 text-sm mb-4">Comentarios de otros viajeros</h3>
                    <div className="space-y-3">
                      {valoraciones.map((val) => (
                        <div key={val.id} className="p-3 bg-slate-50 rounded-xl border border-slate-100 text-xs">
                          <div className="flex justify-between items-center mb-1">
                            <span className="font-bold text-slate-800">{val.usuarioNombre}</span>
                            <span className="text-slate-400 text-[10px]">{val.fecha}</span>
                          </div>
                          <div className="flex text-amber-400 text-xs mb-1">
                            {'★'.repeat(val.estrellas)}
                            {'☆'.repeat(5 - val.estrellas)}
                          </div>
                          <p className="text-slate-600">{val.comentario}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {/* VIEW 6: ACERCA */}
              {currentView === 'view-acerca' && (
                <div className="max-w-3xl mx-auto bg-white rounded-2xl p-6 sm:p-8 shadow-sm border border-slate-100 animate-in fade-in duration-300 space-y-5">
                  <div className="flex items-center gap-3 border-b border-slate-100 pb-4">
                    <div className="w-12 h-12 bg-teal-50 rounded-2xl flex items-center justify-center text-[#0f766e]">
                      <Info className="w-6 h-6" />
                    </div>
                    <div>
                      <h2 className="text-xl font-extrabold text-[#0f766e]">Acerca de Viajes Perdomo</h2>
                      <p className="text-xs text-slate-500">Líderes en transporte interprovincial en Cuba</p>
                    </div>
                  </div>

                  <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
                    Somos una agencia cubana dedicada a brindar el mejor servicio de transporte interprovincial. Con años de experiencia en las carreteras de Cuba, conectamos las principales ciudades del país con modernas guaguas Yutong, garantizando comodidad, seguridad y puntualidad en cada viaje.
                  </p>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                    <div className="p-3 bg-slate-50 rounded-xl border border-slate-100">
                      <strong className="text-[#0f766e] block mb-1">🚍 Flota de Guaguas Yutong</strong>
                      <p className="text-slate-600">
                        Autobuses equipados con aire acondicionado de alto rendimiento, asientos reclinables hasta 160°, suspensión neumática y amplio maletero.
                      </p>
                    </div>
                    <div className="p-3 bg-slate-50 rounded-xl border border-slate-100">
                      <strong className="text-[#0f766e] block mb-1">📍 Cobertura Nacional</strong>
                      <p className="text-slate-600">
                        Salidas diarias desde La Habana hacia Varadero, Trinidad, Santa Clara, Camagüey, Holguín y Santiago de Cuba.
                      </p>
                    </div>
                  </div>

                  <div className="p-4 bg-teal-50/70 border border-teal-200 rounded-xl flex items-center justify-between flex-wrap gap-3">
                    <div>
                      <p className="text-xs font-bold text-[#0f766e]">¿Deseas instalar la aplicación en tu móvil Android?</p>
                      <p className="text-[11px] text-teal-800">Compila el APK directamente con el workflow de GitHub Actions.</p>
                    </div>
                    <button
                      onClick={() => setApkModalOpen(true)}
                      className="bg-[#0f766e] hover:bg-[#115e59] text-white text-xs font-bold px-3 py-1.5 rounded-lg shadow-xs cursor-pointer"
                    >
                      Ver Guía de APK
                    </button>
                  </div>
                </div>
              )}
            </main>
          </div>
        </div>
      )}

      {/* Reservation Booking Modal */}
      {selectedGuagua && user && (
        <ReservaModal
          guagua={selectedGuagua}
          usuario={user}
          onClose={() => setSelectedGuagua(null)}
          onConfirm={handleConfirmReservation}
        />
      )}

      {/* QR Code Modal */}
      {selectedQRReserva && (
        <QRModal reserva={selectedQRReserva} onClose={() => setSelectedQRReserva(null)} />
      )}

      {/* APK GitHub Actions Modal */}
      <APKModal isOpen={apkModalOpen} onClose={() => setApkModalOpen(false)} />

      {/* Floating Toast Notification */}
      {toast && (
        <div
          className={`fixed bottom-5 left-1/2 -translate-x-1/2 z-[10000] px-4 py-3 rounded-xl shadow-2xl text-white text-xs sm:text-sm font-bold flex items-center gap-2 animate-in fade-in slide-in-from-bottom-4 duration-200 ${
            toast.type === 'success' ? 'bg-[#16a34a]' : 'bg-[#dc2626]'
          }`}
        >
          {toast.type === 'success' ? (
            <CheckCircle2 className="w-4 h-4 shrink-0 text-white" />
          ) : (
            <AlertCircle className="w-4 h-4 shrink-0 text-white" />
          )}
          <span>{toast.message}</span>
        </div>
      )}
    </div>
  );
}
