import React, { useState } from 'react';
import { Guagua, Usuario } from '../types';
import { X, Calendar, UserCheck, Phone, Users, ShieldAlert } from 'lucide-react';

interface ReservaModalProps {
  guagua: Guagua | null;
  usuario: Usuario;
  onClose: () => void;
  onConfirm: (data: {
    ci: string;
    telefono: string;
    fechaViaje: string;
    cantidad: number;
  }) => Promise<void>;
}

export const ReservaModal: React.FC<ReservaModalProps> = ({
  guagua,
  usuario,
  onClose,
  onConfirm
}) => {
  const [ci, setCi] = useState('');
  const [telefono, setTelefono] = useState('');
  // Default to tomorrow's date
  const tomorrow = new Date();
  tomorrow.setDate(tomorrow.getDate() + 1);
  const defaultDateStr = tomorrow.toISOString().split('T')[0];

  const [fechaViaje, setFechaViaje] = useState(defaultDateStr);
  const [cantidad, setCantidad] = useState(1);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (!guagua) return null;

  const total = guagua.precio * cantidad;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!ci.trim() || !telefono.trim() || !fechaViaje) {
      setError('Por favor completa todos los campos obligatorios.');
      return;
    }
    if (cantidad < 1 || cantidad > guagua.asientosDisp) {
      setError(`La cantidad de pasajeros debe estar entre 1 y ${guagua.asientosDisp}.`);
      return;
    }

    try {
      setLoading(true);
      setError(null);
      await onConfirm({
        ci: ci.trim(),
        telefono: telefono.trim(),
        fechaViaje,
        cantidad
      });
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Error al procesar la reserva.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/60 z-[8000] flex items-center justify-center p-4 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="bg-white w-full max-w-lg rounded-2xl shadow-2xl overflow-hidden max-h-[92vh] flex flex-col">
        {/* Header */}
        <div className="bg-[#0f766e] text-white px-5 py-4 flex items-center justify-between">
          <div>
            <h3 className="font-extrabold text-lg leading-tight">
              {guagua.origen} → {guagua.destino}
            </h3>
            <p className="text-xs text-teal-100 mt-0.5">Reservar pasaje en guagua Yutong</p>
          </div>
          <button
            onClick={onClose}
            className="text-white/80 hover:text-white p-1 rounded-full hover:bg-white/10 transition-colors"
            title="Cerrar"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 overflow-y-auto space-y-4">
          {/* Trip Summary Pill */}
          <div className="bg-slate-50 border border-slate-200 p-3.5 rounded-xl text-sm flex items-center justify-between">
            <div>
              <div className="font-bold text-slate-800 flex items-center gap-1.5">
                <span>🚌</span> {guagua.unidad}
              </div>
              <div className="text-xs text-slate-500 mt-0.5">
                Salida: {guagua.salida} • Asientos disp: {guagua.asientosDisp}
              </div>
            </div>
            <div className="text-right">
              <div className="text-xs text-slate-500">Precio c/u</div>
              <div className="text-base font-extrabold text-[#f59e0b]">
                {guagua.precio} {guagua.moneda}
              </div>
            </div>
          </div>

          {error && (
            <div className="p-3 bg-red-50 border border-red-200 text-red-700 text-sm rounded-xl flex items-center gap-2">
              <ShieldAlert className="w-4 h-4 shrink-0 text-red-600" />
              <span>{error}</span>
            </div>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-slate-600 mb-1 flex items-center gap-1">
                <UserCheck className="w-3.5 h-3.5 text-[#0f766e]" />
                Carnet de Identidad (CI) *
              </label>
              <input
                type="text"
                required
                maxLength={11}
                placeholder="Ej. 92051412345"
                value={ci}
                onChange={(e) => setCi(e.target.value)}
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0f766e]"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-600 mb-1 flex items-center gap-1">
                <Phone className="w-3.5 h-3.5 text-[#0f766e]" />
                Teléfono de Contacto *
              </label>
              <input
                type="tel"
                required
                placeholder="+53 5xxxxxxx"
                value={telefono}
                onChange={(e) => setTelefono(e.target.value)}
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0f766e]"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-slate-600 mb-1 flex items-center gap-1">
                <Calendar className="w-3.5 h-3.5 text-[#0f766e]" />
                Fecha del viaje *
              </label>
              <input
                type="date"
                required
                value={fechaViaje}
                min={new Date().toISOString().split('T')[0]}
                onChange={(e) => setFechaViaje(e.target.value)}
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0f766e]"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-600 mb-1 flex items-center gap-1">
                <Users className="w-3.5 h-3.5 text-[#0f766e]" />
                Cantidad Pasajeros *
              </label>
              <input
                type="number"
                required
                min={1}
                max={guagua.asientosDisp}
                value={cantidad}
                onChange={(e) => setCantidad(Math.max(1, parseInt(e.target.value) || 1))}
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0f766e]"
              />
            </div>
          </div>

          {/* Passenger & Gestor info summary */}
          <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 text-xs text-slate-600 space-y-1">
            <div className="flex justify-between">
              <span>Titular de la cuenta:</span>
              <strong className="text-slate-800">{usuario.nombre}</strong>
            </div>
            <div className="flex justify-between">
              <span>Gestor asignado:</span>
              <strong className="text-slate-800">{usuario.gestorCodigo}</strong>
            </div>
            <div className="flex justify-between border-t border-slate-200 pt-1 font-semibold text-slate-800 text-sm">
              <span>Total a pagar al abordar:</span>
              <span className="text-[#0f766e] text-base font-extrabold">
                {total} {guagua.moneda}
              </span>
            </div>
          </div>

          <button
            type="submit"
            disabled={loading || guagua.asientosDisp <= 0}
            className="w-full bg-[#16a34a] hover:bg-emerald-700 disabled:bg-slate-300 text-white font-bold py-3 px-4 rounded-xl shadow-md transition-all active:scale-[0.99] cursor-pointer flex items-center justify-center gap-2"
          >
            {loading ? (
              <span>Procesando reserva...</span>
            ) : (
              <>
                <span>✅ Confirmar Reserva ({total} {guagua.moneda})</span>
              </>
            )}
          </button>
        </form>
      </div>
    </div>
  );
};
