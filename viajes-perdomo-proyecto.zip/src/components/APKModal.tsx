import React, { useState } from 'react';
import { X, Copy, Check, Terminal, Download, ShieldCheck, FileArchive, Loader2 } from 'lucide-react';
import { api } from '../services/api';

interface APKModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const APKModal: React.FC<APKModalProps> = ({ isOpen, onClose }) => {
  const [copied, setCopied] = useState(false);
  const [downloadingZip, setDownloadingZip] = useState(false);

  const handleDownloadZip = async () => {
    try {
      setDownloadingZip(true);
      await api.downloadProjectZip();
    } catch (err: unknown) {
      alert('Error al descargar ZIP: ' + (err instanceof Error ? err.message : 'Error desconocido'));
    } finally {
      setDownloadingZip(false);
    }
  };

  if (!isOpen) return null;

  const workflowYaml = `name: Construir APK de Viajes Perdomo

on:
  push:
    branches: [ "main", "master" ]
  pull_request:
    branches: [ "main", "master" ]
  workflow_dispatch:
    inputs:
      build_type:
        description: 'Tipo de compilación (debug o release)'
        required: true
        default: 'debug'
        type: choice
        options:
          - debug
          - release

jobs:
  build-apk:
    name: Compilar APK Android
    runs-on: ubuntu-latest

    steps:
      - name: 📥 Clonar repositorio
        uses: actions/checkout@v4

      - name: 📦 Extraer ZIP si el proyecto fue subido comprimido
        run: |
          if [ -f "project.zip" ]; then
            echo "Detectado project.zip, descomprimiendo..."
            unzip -o project.zip -d .
          elif ls *.zip 1> /dev/null 2>&1; then
            ZIP_FILE=$(ls *.zip | head -n 1)
            echo "Detectado archivo $ZIP_FILE, descomprimiendo..."
            unzip -o "$ZIP_FILE" -d .
          else
            echo "Árbol git estándar detectado."
          fi

      - name: ☕ Configurar Java 17 (Temurin - Sin conflictos)
        uses: actions/setup-java@v4
        with:
          distribution: 'temurin'
          java-version: '17'
          cache: 'gradle'

      - name: 🟢 Configurar Node.js 20 LTS
        uses: actions/setup-node@v4
        with:
          node-version: 20
          cache: 'npm'

      - name: 📦 Instalar dependencias
        run: npm install --legacy-peer-deps

      - name: 🔨 Compilar aplicación web
        run: npm run build

      - name: 📱 Inicializar y Sincronizar Capacitor Android
        run: |
          if [ ! -d "android" ]; then
            npx cap add android
          fi
          npx cap sync android

      - name: 🔧 Permisos de ejecución gradlew
        run: chmod +x android/gradlew

      - name: 🚀 Compilar APK con Gradle
        run: |
          cd android
          ./gradlew assembleDebug --stacktrace --no-daemon

      - name: 🔍 Empaquetar APK y ZIP
        run: |
          mkdir -p output-apk
          APK_PATH=$(find android/app/build/outputs/apk/debug/ -name "*.apk" | head -n 1)
          cp "$APK_PATH" output-apk/viajes-perdomo-debug.apk
          cd output-apk
          zip -r ../viajes-perdomo-apk-bundle.zip .
          cd ..

      - name: 📤 Subir APK a Artifacts
        uses: actions/upload-artifact@v4
        with:
          name: Viajes-Perdomo-APK
          path: output-apk/viajes-perdomo-debug.apk

      - name: 📤 Subir ZIP con APK
        uses: actions/upload-artifact@v4
        with:
          name: Viajes-Perdomo-APK-ZIP
          path: viajes-perdomo-apk-bundle.zip`;

  const handleCopy = () => {
    navigator.clipboard.writeText(workflowYaml);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  return (
    <div className="fixed inset-0 bg-black/60 z-[8000] flex items-center justify-center p-4 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="bg-white w-full max-w-2xl rounded-2xl shadow-2xl overflow-hidden max-h-[92vh] flex flex-col">
        {/* Header */}
        <div className="bg-[#0f766e] text-white px-5 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="text-xl">🤖</span>
            <div>
              <h3 className="font-bold text-lg">Exportar a APK con GitHub Actions</h3>
              <p className="text-xs text-teal-100">Flujo automatizado listo sin conflictos de versiones</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-white/80 hover:text-white p-1 rounded-full hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto space-y-4 text-sm text-slate-700">
          {/* Big Download ZIP Action */}
          <div className="bg-gradient-to-r from-amber-500 to-amber-600 rounded-2xl p-4 text-slate-950 flex flex-col sm:flex-row items-center justify-between gap-3 shadow-md">
            <div>
              <div className="font-black text-base flex items-center gap-2">
                <FileArchive className="w-5 h-5 text-slate-950" />
                <span>Descarga Directa del Proyecto (.ZIP)</span>
              </div>
              <p className="text-xs text-slate-900 mt-0.5 font-medium">
                Listo para subir a GitHub o compilar localmente con Capacitor y Gradle.
              </p>
            </div>
            <button
              onClick={handleDownloadZip}
              disabled={downloadingZip}
              className="w-full sm:w-auto inline-flex items-center justify-center gap-2 bg-slate-950 hover:bg-slate-900 disabled:bg-slate-800 text-amber-400 font-extrabold px-5 py-3 rounded-xl shadow-lg transition-all active:scale-95 text-xs whitespace-nowrap cursor-pointer"
            >
              {downloadingZip ? (
                <>
                  <Loader2 className="w-4 h-4 text-amber-400 animate-spin" />
                  <span>EMPAQUETANDO ZIP...</span>
                </>
              ) : (
                <>
                  <Download className="w-4 h-4 text-amber-400" />
                  <span>DESCARGAR .ZIP AHORA</span>
                </>
              )}
            </button>
          </div>

          <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-3 flex items-start gap-2.5 text-emerald-900">
            <ShieldCheck className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
            <div>
              <p className="font-semibold text-xs uppercase tracking-wider text-emerald-800">Versiones Garantizadas Sin Conflictos</p>
              <p className="text-xs mt-0.5 text-emerald-700">
                <strong>Java 17 (Temurin)</strong> + <strong>Node 20 LTS</strong> + <strong>Capacitor Android</strong> + <strong>Gradle 8</strong>. Incluye soporte para descomprimir archivos ZIP automáticamente.
              </p>
            </div>
          </div>

          <div>
            <h4 className="font-bold text-slate-800 mb-1 flex items-center gap-1.5">
              <span>1️⃣</span> Pasos para obtener tu APK en GitHub:
            </h4>
            <ol className="list-decimal list-inside space-y-1.5 text-xs text-slate-600 pl-1">
              <li>Crea un repositorio en GitHub (público o privado).</li>
              <li>Sube este código (puedes hacer <code className="bg-slate-100 px-1 py-0.5 rounded text-teal-800">git push</code> o subir un archivo <code className="bg-slate-100 px-1 py-0.5 rounded text-teal-800">.zip</code>).</li>
              <li>El archivo <code className="bg-slate-100 px-1 py-0.5 rounded text-teal-800">.github/workflows/build-apk.yml</code> ya está configurado en tu proyecto.</li>
              <li>Ve a la pestaña <strong>Actions</strong> en GitHub: la compilación iniciará automáticamente.</li>
              <li>Al finalizar, en la sección <strong>Artifacts</strong> descarga <strong>Viajes-Perdomo-APK</strong> o <strong>Viajes-Perdomo-APK-ZIP</strong>.</li>
            </ol>
          </div>

          <div>
            <div className="flex items-center justify-between mb-1.5">
              <span className="font-bold text-slate-800 flex items-center gap-1.5 text-xs uppercase tracking-wider">
                <Terminal className="w-4 h-4 text-[#0f766e]" />
                Archivo Workflow (.github/workflows/build-apk.yml)
              </span>
              <button
                onClick={handleCopy}
                className="flex items-center gap-1 text-xs font-semibold px-2.5 py-1 bg-[#0f766e] text-white rounded-lg hover:bg-[#115e59] transition cursor-pointer"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-amber-300" /> : <Copy className="w-3.5 h-3.5" />}
                {copied ? '¡Copiado!' : 'Copiar Workflow YAML'}
              </button>
            </div>

            <pre className="bg-slate-900 text-slate-200 text-xs p-3.5 rounded-xl overflow-x-auto max-h-52 font-mono border border-slate-800">
              {workflowYaml}
            </pre>
          </div>

          <div className="bg-amber-50 border border-amber-200 rounded-xl p-3 text-xs text-amber-900 flex items-start gap-2">
            <FileArchive className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
            <div>
              <strong>Compatibilidad con archivos ZIP:</strong> Si comprimes el proyecto en un archivo <code className="bg-amber-100 px-1 rounded">.zip</code> y lo subes al repo, el workflow lo detecta y lo extrae automáticamente antes de compilar.
            </div>
          </div>

          <button
            onClick={onClose}
            className="w-full bg-[#0f766e] hover:bg-[#115e59] text-white py-2.5 rounded-xl font-bold text-sm transition cursor-pointer"
          >
            Entendido
          </button>
        </div>
      </div>
    </div>
  );
};
