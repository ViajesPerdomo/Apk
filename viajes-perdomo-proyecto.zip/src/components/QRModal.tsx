import React, { useEffect, useState } from 'react';
import QRCode from 'qrcode';
import { Reserva } from '../types';
import { X, Copy, Check, Download, QrCode } from 'lucide-react';

interface QRModalProps {
  reserva: Reserva | null;
  onClose: () => void;
}

export const QRModal: React.FC<QRModalProps> = ({ reserva, onClose }) => {
  const [qrDataUrl, setQrDataUrl] = useState<string>('');
  const [copied, setCopied] = useState<boolean>(false);

  useEffect(() => {
    if (!reserva) {
      setQrDataUrl('');
      return;
    }

    const payload = JSON.stringify({
      boleto: reserva.codigo,
      viaje: reserva.nombre,
      pasajero: reserva.pasajeroNombre,
      ci: reserva.ci,
      asientos: reserva.cantidad,
      fecha: reserva.fechaViaje,
      gestor: reserva.gestorCodigo,
      total: `${reserva.total} ${reserva.moneda}`
    });

    QRCode.toDataURL(payload, {
      width: 280,
      margin: 2,
      color: {
        dark: '#0f172a',
        light: '#ffffff'
      }
    })
      .then((url) => setQrDataUrl(url))
      .catch((err) => {
        console.error('Error generating QR code:', err);
        // Fallback to simple qr code URL if needed
        setQrDataUrl(`https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=${encodeURIComponent(reserva.codigo)}`);
      });
  }, [reserva]);

  if (!reserva) return null;

  const handleCopy = () => {
    navigator.clipboard.writeText(reserva.codigo);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = () => {
    if (!qrDataUrl) return;
    const a = document.createElement('a');
    a.href = qrDataUrl;
    a.download = `Boleto-ViajesPerdomo-${reserva.codigo}.png`;
    a.click();
  };

  return (
    <div className="fixed inset-0 bg-black/60 z-[8000] flex items-center justify-center p-4 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="bg-white w-full max-w-md rounded-2xl shadow-2xl overflow-hidden max-h-[92vh] flex flex-col">
        {/* Header */}
        <div className="bg-[#0f766e] text-white px-5 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <QrCode className="w-5 h-5 text-amber-400" />
            <h3 className="font-bold text-lg">Código QR de tu Reserva</h3>
          </div>
          <button
            onClick={onClose}
            className="text-white/80 hover:text-white p-1 rounded-full hover:bg-white/10 transition-colors"
            title="Cerrar"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="p-6 overflow-y-auto text-center flex flex-col items-center">
          <p className="text-slate-500 text-sm mb-4">
            Muestra este código al gestor al abordar la guagua.
          </p>

          <div className="p-3 bg-slate-50 border-2 border-dashed border-teal-600/30 rounded-2xl shadow-inner mb-4 flex items-center justify-center">
            {qrDataUrl ? (
              <img
                src={qrDataUrl}
                alt={`QR de Reserva ${reserva.codigo}`}
                className="w-56 h-56 object-contain rounded-lg"
              />
            ) : (
              <div className="w-56 h-56 flex items-center justify-center text-slate-400 text-sm">
                Generando código QR...
              </div>
            )}
          </div>

          <div className="w-full bg-slate-100/80 rounded-xl p-3 mb-4 text-left border border-slate-200">
            <div className="flex justify-between items-center mb-1">
              <span className="text-xs text-slate-500 font-semibold uppercase tracking-wider">Boleto Digital</span>
              <span className="text-xs px-2 py-0.5 rounded-full font-bold bg-emerald-100 text-emerald-800 uppercase">
                {reserva.estado}
              </span>
            </div>
            <div className="text-xl font-extrabold text-[#0f766e] flex items-center justify-between">
              <span>{reserva.codigo}</span>
              <button
                onClick={handleCopy}
                className="text-xs flex items-center gap-1 text-slate-600 hover:text-teal-700 bg-white px-2 py-1 rounded-md border border-slate-300 shadow-2xs cursor-pointer active:scale-95 transition"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                {copied ? '¡Copiado!' : 'Copiar'}
              </button>
            </div>
            <div className="text-sm font-medium text-slate-800 mt-2">
              <strong>Ruta:</strong> {reserva.nombre}
            </div>
            <div className="text-xs text-slate-600 mt-1 grid grid-cols-2 gap-1">
              <div><strong>Pasajero:</strong> {reserva.pasajeroNombre}</div>
              <div><strong>CI:</strong> {reserva.ci}</div>
              <div><strong>Fecha:</strong> {reserva.fechaViaje}</div>
              <div><strong>Asientos:</strong> {reserva.cantidad}</div>
              <div><strong>Total:</strong> {reserva.total} {reserva.moneda}</div>
              <div><strong>Gestor:</strong> {reserva.gestorCodigo}</div>
            </div>
          </div>

          <div className="w-full grid grid-cols-2 gap-2 mt-2">
            <button
              onClick={handleDownload}
              className="flex items-center justify-center gap-1.5 bg-slate-800 hover:bg-slate-900 text-white py-2.5 px-3 rounded-xl font-medium text-sm transition-colors cursor-pointer"
            >
              <Download className="w-4 h-4" />
              Guardar QR
            </button>
            <button
              onClick={onClose}
              className="bg-[#0f766e] hover:bg-[#115e59] text-white py-2.5 px-3 rounded-xl font-bold text-sm transition-colors cursor-pointer"
            >
              Listo
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
