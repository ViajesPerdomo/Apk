export interface Gestor {
  usuario: string;
  nombre: string;
  telefono: string;
  agencia: string;
}

export interface Guagua {
  id: string;
  origen: string;
  destino: string;
  unidad: string;
  precio: number;
  moneda: string;
  asientosTotales: number;
  asientosDisp: number;
  salida: string;
  llegada?: string;
  region: 'este' | 'centro' | 'oeste' | 'especial';
  oferta: boolean;
  imagen: string;
  activa: boolean;
  caracteristicas?: string[];
}

export interface Reserva {
  id: string;
  codigo: string;
  guaguaId: string;
  nombre: string;
  pasajeroNombre: string;
  email: string;
  ci: string;
  telefono: string;
  gestorCodigo: string;
  fechaViaje: string;
  cantidad: number;
  precioUnitario: number;
  total: number;
  moneda: string;
  estado: 'pendiente' | 'confirmada' | 'cancelada' | 'completada';
  creadoEn: string;
}

export interface Usuario {
  id: string;
  nombre: string;
  email: string;
  gestorCodigo: string;
}

export interface Valoracion {
  id: string;
  usuarioNombre: string;
  estrellas: number;
  comentario: string;
  fecha: string;
}
