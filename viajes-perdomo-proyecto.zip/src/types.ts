export interface Gestor {
  usuario: string;
  nombre: string;
  telefono?: string;
  agencia?: string;
}

export interface Guagua {
  id: string;
  origen: string;
  destino: string;
  unidad: string;
  precio: number;
  moneda: string;
  asientosTotales?: number;
  asientos?: number;
  asientosDisp: number;
  salida: string;
  llegada?: string;
  duracion?: string;
  region: 'este' | 'centro' | 'oeste' | 'especial' | string;
  oferta: boolean;
  imagen: string;
  activa: boolean;
  descripcion?: string;
  caracteristicas?: string[];
}

export interface Reserva {
  id: string;
  codigo: string;
  guaguaId: string;
  nombre: string;
  pasajeroNombre?: string;
  email: string;
  ci: string;
  telefono: string;
  gestorCodigo?: string;
  fechaViaje: string;
  cantidad: number;
  precioUnitario?: number;
  total: number;
  moneda: string;
  estado: 'pendiente' | 'confirmada' | 'cancelada' | 'completada' | string;
  creadoEn?: string;
  createdAt?: string;
}

export interface Usuario {
  id?: string;
  nombre: string;
  email: string;
  gestorCodigo?: string;
}

export interface Valoracion {
  id: string;
  usuarioNombre: string;
  estrellas: number;
  comentario: string;
  fecha: string;
}
