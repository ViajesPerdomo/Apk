import { Gestor, Guagua, Reserva, Usuario, Valoracion } from '../types';

const INITIAL_GESTORES: Gestor[] = [
  { usuario: 'CR01', nombre: 'Carlos Rodríguez', telefono: '+53 5234 5678', agencia: 'Terminal Central La Habana' },
  { usuario: 'ED04', nombre: 'Elena Díaz', telefono: '+53 5345 6789', agencia: 'Varadero Centro' },
  { usuario: 'MT09', nombre: 'Marcos Torres', telefono: '+53 5456 7890', agencia: 'Santiago de Cuba Sur' },
  { usuario: 'YP12', nombre: 'Yailenys Pérez', telefono: '+53 5567 8901', agencia: 'Holguín Monumento' },
  { usuario: 'AS05', nombre: 'Armando Suárez', telefono: '+53 5678 9012', agencia: 'Trinidad Colonial' }
];

const INITIAL_GUAGUAS: Guagua[] = [
  {
    id: 'g-101',
    origen: 'La Habana',
    destino: 'Varadero',
    unidad: 'Yutong #104 Climatizada',
    precio: 2500,
    moneda: 'CUP',
    asientosTotales: 44,
    asientosDisp: 18,
    salida: '07:30 AM',
    llegada: '10:00 AM',
    region: 'oeste',
    oferta: true,
    imagen: 'https://images.unsplash.com/photo-1544620347-c4fd4a3d5957?auto=format&fit=crop&w=800&q=80',
    activa: true,
    caracteristicas: ['A/C Doble Turbina', 'Música y Video', 'Cargador USB']
  },
  {
    id: 'g-102',
    origen: 'La Habana',
    destino: 'Santiago de Cuba',
    unidad: 'Yutong #302 Gran Confort',
    precio: 5200,
    moneda: 'CUP',
    asientosTotales: 48,
    asientosDisp: 12,
    salida: '06:00 AM',
    llegada: '08:30 PM',
    region: 'este',
    oferta: false,
    imagen: 'https://images.unsplash.com/photo-1570125909232-eb263c188f7e?auto=format&fit=crop&w=800&q=80',
    activa: true,
    caracteristicas: ['Asientos Reclinables 160°', 'WiFi Satelital', 'Nevera a bordo', 'Baño']
  },
  {
    id: 'g-103',
    origen: 'La Habana',
    destino: 'Trinidad',
    unidad: 'Yutong #215 Colonial',
    precio: 3600,
    moneda: 'CUP',
    asientosTotales: 44,
    asientosDisp: 24,
    salida: '08:15 AM',
    llegada: '01:30 PM',
    region: 'centro',
    oferta: true,
    imagen: 'https://images.unsplash.com/photo-1506015391300-4802dc74de2e?auto=format&fit=crop&w=800&q=80',
    activa: true,
    caracteristicas: ['A/C Confort', 'Espacio para 2 maletas', 'Música ambiental']
  },
  {
    id: 'g-104',
    origen: 'La Habana',
    destino: 'Holguín',
    unidad: 'Yutong #410 Expreso',
    precio: 4800,
    moneda: 'CUP',
    asientosTotales: 48,
    asientosDisp: 8,
    salida: '05:30 AM',
    llegada: '06:00 PM',
    region: 'este',
    oferta: false,
    imagen: 'https://images.unsplash.com/photo-1544620347-c4fd4a3d5957?auto=format&fit=crop&w=800&q=80',
    activa: true,
    caracteristicas: ['Parada Almuerzo en Sancti Spíritus', 'Cargadores individuales', 'WiFi']
  },
  {
    id: 'g-105',
    origen: 'Varadero',
    destino: 'La Habana',
    unidad: 'Yutong #108 Retorno',
    precio: 2500,
    moneda: 'CUP',
    asientosTotales: 44,
    asientosDisp: 30,
    salida: '04:00 PM',
    llegada: '06:45 PM',
    region: 'oeste',
    oferta: false,
    imagen: 'https://images.unsplash.com/photo-1570125909232-eb263c188f7e?auto=format&fit=crop&w=800&q=80',
    activa: true,
    caracteristicas: ['A/C Climatizado', 'Maletero amplio', 'Conductor profesional']
  },
  {
    id: 'g-106',
    origen: 'Santiago de Cuba',
    destino: 'La Habana',
    unidad: 'Yutong #304 Nocturna',
    precio: 5200,
    moneda: 'CUP',
    asientosTotales: 48,
    asientosDisp: 15,
    salida: '07:00 PM',
    llegada: '09:00 AM (+1)',
    region: 'este',
    oferta: true,
    imagen: 'https://images.unsplash.com/photo-1506015391300-4802dc74de2e?auto=format&fit=crop&w=800&q=80',
    activa: true,
    caracteristicas: ['Viaje Nocturno Directo', 'Mantas de viaje', 'Asientos semicama', 'Baño']
  },
  {
    id: 'g-107',
    origen: 'Trinidad',
    destino: 'Varadero',
    unidad: 'Yutong #512 Tour Especial',
    precio: 4200,
    moneda: 'CUP',
    asientosTotales: 36,
    asientosDisp: 10,
    salida: '09:00 AM',
    llegada: '02:30 PM',
    region: 'especial',
    oferta: true,
    imagen: 'https://images.unsplash.com/photo-1544620347-c4fd4a3d5957?auto=format&fit=crop&w=800&q=80',
    activa: true,
    caracteristicas: ['Ruta Panorámica Topes de Collantes', 'Guía Turístico', 'Refrigerio incluido']
  }
];

const INITIAL_RESERVAS: Reserva[] = [
  {
    id: 'res-demo-1',
    codigo: 'VP-7842',
    guaguaId: 'g-101',
    nombre: 'La Habana → Varadero',
    pasajeroNombre: 'Juan Carlos Pérez',
    email: 'dgrisel940@gmail.com',
    ci: '91042314582',
    telefono: '+53 5212 3456',
    gestorCodigo: 'CR01',
    fechaViaje: '2026-11-15',
    cantidad: 2,
    precioUnitario: 2500,
    total: 5000,
    moneda: 'CUP',
    estado: 'confirmada',
    creadoEn: '2026-11-09T18:30:00Z'
  }
];

// Helper for local storage persistence when running offline
function getStored<T>(key: string, fallback: T): T {
  try {
    const val = localStorage.getItem(key);
    return val ? JSON.parse(val) : fallback;
  } catch {
    return fallback;
  }
}

function setStored<T>(key: string, data: T) {
  try {
    localStorage.setItem(key, JSON.stringify(data));
  } catch {
    // Ignore storage quota
  }
}

export const api = {
  async getGestores(): Promise<Gestor[]> {
    try {
      const res = await fetch('/api/gestores');
      if (res.ok) {
        const data = await res.json();
        setStored('vp_gestores', data);
        return data;
      }
    } catch {
      // Fallback to local storage or initial list
    }
    return getStored('vp_gestores', INITIAL_GESTORES);
  },

  async login(email: string, password: string): Promise<Usuario> {
    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Error al iniciar sesión');
      return data.usuario;
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Error de conexión';
      // If server is not responding (e.g. offline APK), allow login with local mock
      if (msg.includes('Failed to fetch') || msg.includes('NetworkError')) {
        const user: Usuario = {
          id: 'u-local-' + Date.now(),
          nombre: email.split('@')[0],
          email,
          gestorCodigo: 'CR01'
        };
        return user;
      }
      throw err;
    }
  },

  async register(nombre: string, email: string, password: string, gestorCodigo: string): Promise<Usuario> {
    try {
      const res = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ nombre, email, password, gestorCodigo })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Error en el registro');
      return data.usuario;
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Error';
      if (msg.includes('Failed to fetch') || msg.includes('NetworkError')) {
        const user: Usuario = {
          id: 'u-local-' + Date.now(),
          nombre,
          email,
          gestorCodigo
        };
        return user;
      }
      throw err;
    }
  },

  async updatePerfil(email: string, nombre: string, password?: string): Promise<Usuario> {
    try {
      const res = await fetch('/api/perfil', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, nombre, password })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Error al actualizar perfil');
      return data.usuario;
    } catch {
      return {
        id: 'u-current',
        nombre,
        email,
        gestorCodigo: 'CR01'
      };
    }
  },

  async getGuaguas(): Promise<Guagua[]> {
    try {
      const res = await fetch('/api/guaguas');
      if (res.ok) {
        const data = await res.json();
        setStored('vp_guaguas', data);
        return data;
      }
    } catch {
      // offline fallback
    }
    return getStored('vp_guaguas', INITIAL_GUAGUAS);
  },

  async getReservas(email?: string): Promise<Reserva[]> {
    try {
      const url = email ? `/api/reservas?email=${encodeURIComponent(email)}` : '/api/reservas';
      const res = await fetch(url);
      if (res.ok) {
        const data = await res.json();
        setStored('vp_reservas', data);
        return data;
      }
    } catch {
      // offline fallback
    }
    const all = getStored('vp_reservas', INITIAL_RESERVAS);
    if (email) {
      return all.filter((r) => r.email.toLowerCase() === email.toLowerCase());
    }
    return all;
  },

  async createReserva(payload: {
    nombre: string;
    email: string;
    gestorCodigo: string;
    ci: string;
    telefono: string;
    guaguaId: string;
    fechaViaje: string;
    cantidad: number;
  }): Promise<{ codigo: string; reserva: Reserva }> {
    try {
      const res = await fetch('/api/reservas', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Error al crear reserva');
      return data;
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Error';
      if (msg.includes('Failed to fetch') || msg.includes('NetworkError')) {
        // Offline reservation fallback
        const guaguas = getStored('vp_guaguas', INITIAL_GUAGUAS);
        const guagua = guaguas.find((g) => g.id === payload.guaguaId);
        const code = `VP-${Math.floor(1000 + Math.random() * 9000)}`;
        const nueva: Reserva = {
          id: 'res-off-' + Date.now(),
          codigo: code,
          guaguaId: payload.guaguaId,
          nombre: guagua ? `${guagua.origen} → ${guagua.destino}` : 'Viaje Interprovincial',
          pasajeroNombre: payload.nombre,
          email: payload.email,
          ci: payload.ci,
          telefono: payload.telefono,
          gestorCodigo: payload.gestorCodigo,
          fechaViaje: payload.fechaViaje,
          cantidad: payload.cantidad,
          precioUnitario: guagua ? guagua.precio : 2500,
          total: (guagua ? guagua.precio : 2500) * payload.cantidad,
          moneda: 'CUP',
          estado: 'confirmada',
          creadoEn: new Date().toISOString()
        };
        const exist = getStored<Reserva[]>('vp_reservas', INITIAL_RESERVAS);
        setStored('vp_reservas', [nueva, ...exist]);
        return { codigo: code, reserva: nueva };
      }
      throw err;
    }
  },

  async cancelReserva(id: string): Promise<void> {
    try {
      const res = await fetch(`/api/reservas/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ estado: 'cancelada' })
      });
      if (!res.ok) {
        const data = await res.json().catch(() => ({}));
        throw new Error(data.error || 'No se pudo cancelar');
      }
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : '';
      if (msg.includes('Failed to fetch') || msg.includes('NetworkError')) {
        const reservas = getStored<Reserva[]>('vp_reservas', INITIAL_RESERVAS);
        const updated = reservas.map((r) => (r.id === id ? { ...r, estado: 'cancelada' as const } : r));
        setStored('vp_reservas', updated);
        return;
      }
      throw err;
    }
  },

  async downloadProjectZip(): Promise<void> {
    const res = await fetch('/api/download-zip');
    if (!res.ok) {
      throw new Error('Error al generar el archivo ZIP en el servidor');
    }
    const blob = await res.blob();
    // Explicitly enforce application/zip
    const zipBlob = new Blob([blob], { type: 'application/zip' });
    const url = URL.createObjectURL(zipBlob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', 'viajes-perdomo-proyecto.zip');
    link.style.display = 'none';
    document.body.appendChild(link);
    link.click();
    setTimeout(() => {
      URL.revokeObjectURL(url);
      link.remove();
    }, 2000);
  },

  async getValoraciones(): Promise<Valoracion[]> {
    try {
      const res = await fetch('/api/valoraciones');
      if (res.ok) return await res.json();
    } catch {
      // fallback
    }
    return [
      {
        id: 'val-1',
        usuarioNombre: 'Yoandry Morales',
        estrellas: 5,
        comentario: 'Excelente servicio desde La Habana hasta Santiago. El aire acondicionado perfecto y los choferes muy atentos.',
        fecha: '08 Nov 2026'
      },
      {
        id: 'val-2',
        usuarioNombre: 'Beatriz Delgado',
        estrellas: 5,
        comentario: 'Puntuales en la salida y la guagua Yutong comodísima. Recomiendo reservar con tiempo con el gestor Carlos.',
        fecha: '06 Nov 2026'
      }
    ];
  },

  async sendValoracion(usuarioNombre: string, estrellas: number, comentario: string): Promise<void> {
    try {
      await fetch('/api/valoraciones', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ usuarioNombre, estrellas, comentario })
      });
    } catch {
      // ignored for offline
    }
  }
};
