import { Gestor, Guagua, Reserva, Usuario, Valoracion } from '../types';

const RENDER_BASE = 'https://viajesperdomos.onrender.com';
export const API_BASE = (import.meta.env.VITE_API_URL || RENDER_BASE).replace(/\/$/, '');

// Helper for local storage persistence
function getStored<T>(key: string, fallback: T): T {
  try {
    const val = localStorage.getItem(key);
    return val ? JSON.parse(val) : fallback;
  } catch {
    return fallback;
  }
}

function setStored<T>(key: string, data: T) {
  try {
    localStorage.setItem(key, JSON.stringify(data));
  } catch {
    // Ignore quota errors
  }
}

export const api = {
  /**
   * Carga la lista de gestores desde tu servidor Render
   * GET https://viajesperdomos.onrender.com/api/gestores
   */
  async getGestores(): Promise<Gestor[]> {
    try {
      const res = await fetch(`${API_BASE}/api/gestores`);
      if (res.ok) {
        const data: Gestor[] = await res.json();
        setStored('vp_gestores', data);
        return data;
      }
    } catch (err) {
      console.warn('Advertencia al consultar gestores en Render:', err);
    }
    return getStored('vp_gestores', [
      { usuario: 'Lisvania', nombre: 'Lisvania' },
      { usuario: 'Kendry', nombre: 'Kendry' }
    ]);
  },

  /**
   * Inicia sesión en tu servidor Render
   * POST https://viajesperdomos.onrender.com/api/auth/login
   */
  async login(email: string, password: string): Promise<Usuario> {
    const res = await fetch(`${API_BASE}/api/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password })
    });
    const data = await res.json();
    if (!res.ok) {
      throw new Error(data.error || 'Credenciales inválidas');
    }
    const user: Usuario = data.usuario || data;
    return user;
  },

  /**
   * Registra un nuevo usuario en tu servidor Render
   * POST https://viajesperdomos.onrender.com/api/auth/register
   */
  async register(nombre: string, email: string, password: string, gestorCodigo: string): Promise<Usuario> {
    const res = await fetch(`${API_BASE}/api/auth/register`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ nombre, email, password, gestorCodigo })
    });
    const data = await res.json();
    if (!res.ok) {
      throw new Error(data.error || 'Error al registrar usuario en el servidor');
    }
    const user: Usuario = data.usuario || data;
    return user;
  },

  /**
   * Actualiza el perfil
   */
  async updatePerfil(email: string, nombre: string, password?: string): Promise<Usuario> {
    try {
      const res = await fetch(`${API_BASE}/api/perfil`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, nombre, password })
      });
      if (res.ok) {
        const data = await res.json();
        return data.usuario || data;
      }
    } catch {
      // Ignorar si el endpoint PUT no está presente aún en el servidor Render
    }
    return {
      nombre,
      email,
      gestorCodigo: 'Kendry'
    };
  },

  /**
   * Obtiene la lista de guaguas activas desde tu servidor Render
   * GET https://viajesperdomos.onrender.com/api/guaguas
   */
  async getGuaguas(): Promise<Guagua[]> {
    try {
      const res = await fetch(`${API_BASE}/api/guaguas`);
      if (res.ok) {
        const data: Guagua[] = await res.json();
        setStored('vp_guaguas', data);
        return data;
      }
    } catch (err) {
      console.warn('Advertencia al consultar guaguas en Render:', err);
    }
    return getStored('vp_guaguas', []);
  },

  /**
   * Obtiene las reservas desde tu servidor Render
   * GET https://viajesperdomos.onrender.com/api/reservas
   */
  async getReservas(email?: string): Promise<Reserva[]> {
    try {
      const res = await fetch(`${API_BASE}/api/reservas`);
      if (res.ok) {
        const data: Reserva[] = await res.json();
        setStored('vp_reservas', data);
        if (email) {
          return data.filter((r) => r.email && r.email.toLowerCase() === email.toLowerCase());
        }
        return data;
      }
    } catch (err) {
      console.warn('Advertencia al consultar reservas en Render:', err);
    }
    const stored = getStored<Reserva[]>('vp_reservas', []);
    if (email) {
      return stored.filter((r) => r.email && r.email.toLowerCase() === email.toLowerCase());
    }
    return stored;
  },

  /**
   * Crea una nueva reserva en tu servidor Render
   * POST https://viajesperdomos.onrender.com/api/reservas
   */
  async createReserva(payload: {
    nombre: string;
    email: string;
    gestorCodigo: string;
    ci: string;
    telefono: string;
    guaguaId: string;
    fechaViaje: string;
    cantidad: number;
  }): Promise<{ codigo: string; reserva: Reserva }> {
    const res = await fetch(`${API_BASE}/api/reservas`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    const data = await res.json();
    if (!res.ok) {
      throw new Error(data.error || 'Error al crear la reserva en el servidor');
    }
    const codigo = data.codigo || (data.reserva && data.reserva.codigo) || data.id || 'VP-OK';
    const reserva = data.reserva || data;
    return { codigo, reserva };
  },

  /**
   * Cancela una reserva en tu servidor Render
   * PUT https://viajesperdomos.onrender.com/api/reservas/:id
   */
  async cancelReserva(id: string): Promise<void> {
    const res = await fetch(`${API_BASE}/api/reservas/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ estado: 'cancelada' })
    });
    if (!res.ok) {
      const data = await res.json().catch(() => ({}));
      throw new Error(data.error || 'No se pudo cancelar la reserva en el servidor');
    }
  },

  /**
   * Descarga el ZIP completo del proyecto con extensión .zip garantizada
   */
  async downloadProjectZip(): Promise<void> {
    const res = await fetch('/api/download-zip');
    if (!res.ok) {
      throw new Error('Error al generar el archivo ZIP');
    }
    const blob = await res.blob();
    const zipBlob = new Blob([blob], { type: 'application/zip' });
    const url = URL.createObjectURL(zipBlob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', 'viajes-perdomo-proyecto.zip');
    link.style.display = 'none';
    document.body.appendChild(link);
    link.click();
    setTimeout(() => {
      URL.revokeObjectURL(url);
      link.remove();
    }, 2000);
  },

  async getValoraciones(): Promise<Valoracion[]> {
    return [
      {
        id: 'val-1',
        usuarioNombre: 'Yoandry Morales',
        estrellas: 5,
        comentario: 'Excelente servicio en la ruta Habana - Santiago de Cuba. La guagua Yutong muy cómoda.',
        fecha: '08 Nov 2026'
      },
      {
        id: 'val-2',
        usuarioNombre: 'Beatriz Delgado',
        estrellas: 5,
        comentario: 'Gestor Kendry muy atento en la confirmación. Puntualidad en la salida.',
        fecha: '06 Nov 2026'
      }
    ];
  },

  async sendValoracion(_usuarioNombre: string, _estrellas: number, _comentario: string): Promise<void> {
    // Local / client review
  }
};
