export type WordCategory =
  | 'Animal'
  | 'Objeto'
  | 'Comida'
  | 'Bebida'
  | 'Lugar o Cosa'
  | 'Deporte'
  | 'Ciencia'
  | 'Medicina'
  | 'Música'
  | 'Literatura';

export interface WordEntry {
  word: string;
  category: WordCategory;
}

const ANIMALES: string[] = [
  'León', 'Tigre', 'Elefante', 'Jirafa', 'Cebra', 'Hipopótamo', 'Rinoceronte', 'Cocodrilo', 'Caimán', 'Serpiente',
  'Cobra', 'Víbora', 'Tortuga', 'Iguana', 'Camaleón', 'Lagartija', 'Rana', 'Sapo', 'Salamandra', 'Águila',
  'Halcón', 'Búho', 'Lechuza', 'Cuervo', 'Paloma', 'Gorrión', 'Colibrí', 'Tucán', 'Loro', 'Guacamayo',
  'Flamenco', 'Cisne', 'Pato', 'Ganso', 'Pingüino', 'Avestruz', 'Pavo real', 'Gallina', 'Gallo', 'Pavo',
  'Perro', 'Gato', 'Conejo', 'Hámster', 'Cobaya', 'Ratón', 'Rata', 'Ardilla', 'Castor', 'Nutria',
  'Zorro', 'Lobo', 'Oso polar', 'Oso pardo', 'Oso panda', 'Mapache', 'Tejón', 'Erizo', 'Topo', 'Murciélago',
  'Caballo', 'Burro', 'Mula', 'Vaca', 'Toro', 'Oveja', 'Cabra', 'Cerdo', 'Jabalí', 'Ciervo',
  'Alce', 'Reno', 'Camello', 'Dromedario', 'Llama', 'Alpaca', 'Canguro', 'Koala', 'Ornitorrinco', 'Mono',
  'Chimpancé', 'Gorila', 'Orangután', 'Lemur', 'Perezoso', 'Armadillo', 'Hormiga', 'Abeja', 'Avispa', 'Mariposa',
  'Libélula', 'Escarabajo', 'Grillo', 'Saltamontes', 'Araña', 'Escorpión', 'Delfín', 'Ballena', 'Tiburón', 'Pulpo'
];

const OBJETOS: string[] = [
  'Reloj', 'Lámpara', 'Silla', 'Mesa', 'Sofá', 'Cama', 'Almohada', 'Espejo', 'Cuadro', 'Cortina',
  'Alfombra', 'Escoba', 'Trapeador', 'Aspiradora', 'Plancha', 'Lavadora', 'Secadora', 'Nevera', 'Microondas', 'Horno',
  'Tostadora', 'Licuadora', 'Cafetera', 'Sartén', 'Olla', 'Cuchillo', 'Tenedor', 'Cuchara', 'Plato', 'Vaso',
  'Taza', 'Botella', 'Termo', 'Mochila', 'Maleta', 'Cartera', 'Billetera', 'Paraguas', 'Gafas', 'Sombrero',
  'Gorra', 'Bufanda', 'Guantes', 'Abrigo', 'Chaqueta', 'Camisa', 'Pantalón', 'Zapatos', 'Zapatillas', 'Calcetines',
  'Cinturón', 'Corbata', 'Anillo', 'Collar', 'Pulsera', 'Pendientes', 'Llave', 'Candado', 'Linterna', 'Vela',
  'Fósforo', 'Encendedor', 'Tijeras', 'Pegamento', 'Cinta adhesiva', 'Regla', 'Lápiz', 'Bolígrafo', 'Borrador', 'Cuaderno',
  'Libro', 'Diccionario', 'Periódico', 'Revista', 'Sobre', 'Sello', 'Calculadora', 'Teléfono', 'Computadora', 'Teclado',
  'Ratón de computadora', 'Pantalla', 'Impresora', 'Cámara', 'Auriculares', 'Altavoz', 'Micrófono', 'Televisor', 'Control remoto', 'Consola',
  'Bicicleta', 'Patineta', 'Casco', 'Martillo', 'Destornillador', 'Alicates', 'Serrucho', 'Taladro', 'Brújula', 'Binoculares'
];

const COMIDAS: string[] = [
  'Pizza', 'Hamburguesa', 'Perro caliente', 'Taco', 'Burrito', 'Quesadilla', 'Nachos', 'Empanada', 'Arepa', 'Tamal',
  'Paella', 'Tortilla española', 'Croqueta', 'Lasaña', 'Espagueti', 'Ravioli', 'Macarrones', 'Risotto', 'Sushi', 'Ramen',
  'Arroz frito', 'Pollo asado', 'Milanesa', 'Bistec', 'Costillas', 'Albóndigas', 'Salchicha', 'Tocino', 'Jamón', 'Queso',
  'Mantequilla', 'Yogur', 'Huevo frito', 'Tortilla francesa', 'Panqueque', 'Gofre', 'Tostada', 'Cruasán', 'Dona', 'Magdalena',
  'Pastel', 'Tarta de queso', 'Flan', 'Pudín', 'Gelatina', 'Helado', 'Paleta', 'Brownie', 'Galleta', 'Churro',
  'Chocolate', 'Caramelo', 'Chicle', 'Palomitas', 'Papas fritas', 'Puré de papas', 'Ensalada', 'Sopa', 'Crema de verduras', 'Gazpacho',
  'Lentejas', 'Frijoles', 'Garbanzos', 'Ceviche', 'Pescado frito', 'Salmón', 'Atún', 'Camarones', 'Langosta', 'Calamar',
  'Manzana', 'Plátano', 'Naranja', 'Fresa', 'Uva', 'Sandía', 'Melón', 'Piña', 'Mango', 'Papaya',
  'Aguacate', 'Tomate', 'Zanahoria', 'Brócoli', 'Coliflor', 'Espinaca', 'Lechuga', 'Pepino', 'Cebolla', 'Ajo',
  'Maíz', 'Arroz blanco', 'Pan', 'Baguette', 'Pretzel', 'Miel', 'Mermelada', 'Salsa de tomate', 'Mostaza', 'Aceituna'
];

const BEBIDAS: string[] = [
  'Agua', 'Agua con gas', 'Agua de coco', 'Agua tónica', 'Refresco de cola', 'Gaseosa de limón', 'Gaseosa de naranja', 'Jugo de naranja', 'Jugo de manzana', 'Jugo de piña',
  'Jugo de uva', 'Jugo de mango', 'Jugo de fresa', 'Jugo de tomate', 'Jugo de zanahoria', 'Limonada', 'Naranjada', 'Horchata', 'Chicha', 'Tamarindo',
  'Jamaica', 'Café solo', 'Café con leche', 'Capuchino', 'Espresso', 'Latte', 'Café helado', 'Descafeinado', 'Chocolate caliente', 'Chocolate frío',
  'Té negro', 'Té verde', 'Té rojo', 'Té blanco', 'Té de manzanilla', 'Té de menta', 'Té helado', 'Matcha', 'Mate', 'Infusión de jengibre',
  'Leche entera', 'Leche de almendras', 'Leche de soja', 'Leche de avena', 'Leche con chocolate', 'Malteada de vainilla', 'Malteada de fresa', 'Batido de plátano', 'Batido verde', 'Smoothie de frutos rojos',
  'Cerveza', 'Cerveza negra', 'Cerveza sin alcohol', 'Vino tinto', 'Vino blanco', 'Vino rosado', 'Champán', 'Sidra', 'Sangría', 'Tinto de verano',
  'Margarita', 'Mojito', 'Piña colada', 'Daiquiri', 'Caipiriña', 'Cuba libre', 'Gin tonic', 'Cosmopolitan', 'Bloody Mary', 'Negroni',
  'Whisky', 'Ron', 'Vodka', 'Tequila', 'Ginebra', 'Brandy', 'Coñac', 'Mezcal', 'Pisco', 'Aguardiente',
  'Licor de café', 'Amaretto', 'Crema irlandesa', 'Sake', 'Kombucha', 'Kéfir', 'Bebida energética', 'Bebida isotónica', 'Suero oral', 'Caldo caliente',
  'Ponche de frutas', 'Ponche de huevo', 'Granizado de limón', 'Granizado de café', 'Frappé', 'Atole', 'Champurrado', 'Cacao', 'Cerveza de raíz', 'Ginger ale'
];

const LUGARES_Y_COSAS: string[] = [
  'Playa', 'Montaña', 'Bosque', 'Desierto', 'Selva', 'Río', 'Lago', 'Océano', 'Cascada', 'Volcán',
  'Isla', 'Cueva', 'Glaciar', 'Arcoíris', 'Nube', 'Lluvia', 'Nieve', 'Tormenta', 'Relámpago', 'Viento',
  'Sol', 'Luna', 'Estrella', 'Planeta', 'Cometa', 'Galaxia', 'Astronauta', 'Cohete', 'Satélite', 'Telescopio',
  'Hospital', 'Escuela', 'Universidad', 'Biblioteca', 'Museo', 'Cine', 'Teatro', 'Circo', 'Estadio', 'Gimnasio',
  'Restaurante', 'Cafetería', 'Panadería', 'Supermercado', 'Farmacia', 'Banco', 'Hotel', 'Aeropuerto', 'Estación de tren', 'Puerto',
  'Puente', 'Castillo', 'Palacio', 'Torre', 'Pirámide', 'Faro', 'Molino', 'Iglesia', 'Catedral', 'Plaza',
  'Parque', 'Zoológico', 'Acuario', 'Jardín', 'Cementerio', 'Cárcel', 'Comisaría', 'Estación de bomberos', 'Fábrica', 'Oficina',
  'Ajedrez', 'Póker', 'Dominó', 'Dado', 'Rompecabezas', 'Ruleta', 'Billar', 'Dardos', 'Laberinto', 'Carpa',
  'Avión', 'Helicóptero', 'Tren', 'Metro', 'Autobús', 'Taxi', 'Barco', 'Submarino', 'Velero', 'Globo aerostático',
  'Motocicleta', 'Camión', 'Ambulancia', 'Tranvía', 'Teleférico', 'Semáforo', 'Carretera', 'Túnel', 'Ascensor', 'Escalera'
];

const DEPORTES: string[] = [
  'Fútbol', 'Baloncesto', 'Tenis', 'Natación', 'Boxeo', 'Voleibol', 'Béisbol', 'Atletismo', 'Ciclismo', 'Golf',
  'Rugby', 'Hockey', 'Surf', 'Esquí', 'Snowboard', 'Patinaje artístico', 'Gimnasia', 'Karate', 'Judo', 'Taekwondo',
  'Esgrima', 'Arquería', 'Remo', 'Vela', 'Buceo', 'Waterpolo', 'Balonmano', 'Bádminton', 'Tenis de mesa', 'Pádel',
  'Squash', 'Escalada', 'Alpinismo', 'Maratón', 'Triatlón', 'Halterofilia', 'Lucha libre', 'Automovilismo', 'Motociclismo', 'Equitación',
  'Polo', 'Críquet', 'Fútbol americano', 'Softbol', 'Paracaidismo', 'Salto con pértiga', 'Lanzamiento de jabalina', 'Lanzamiento de disco', 'Senderismo', 'Ajedrez deportivo',
  'Portería', 'Raqueta', 'Balón', 'Medalla', 'Trofeo', 'Árbitro', 'Entrenador', 'Tarjeta roja', 'Penalti', 'Olimpiadas'
];

const CIENCIA: string[] = [
  'Átomo', 'Molécula', 'Electrón', 'Protón', 'Neutrón', 'Gravedad', 'Electricidad', 'Magnetismo', 'Energía solar', 'Fotosíntesis',
  'ADN', 'Célula', 'Bacteria', 'Microscopio', 'Probeta', 'Matraz', 'Laboratorio', 'Experimento', 'Hipótesis', 'Teoría',
  'Física', 'Química', 'Biología', 'Astronomía', 'Geología', 'Matemáticas', 'Ecuación', 'Fracción', 'Geometría', 'Algoritmo',
  'Agujero negro', 'Supernova', 'Órbita', 'Eclipse', 'Meteorito', 'Vía Láctea', 'Gravedad cero', 'Velocidad de la luz', 'Espectro', 'Prisma',
  'Oxígeno', 'Hidrógeno', 'Carbono', 'Oro químico', 'Hierro', 'Mercurio', 'Fósil', 'Dinosaurio', 'Evolución', 'Ecosistema',
  'Terremoto', 'Placa tectónica', 'Termómetro', 'Barómetro', 'Imán', 'Batería eléctrica', 'Circuito', 'Láser', 'Robótica', 'Inteligencia artificial'
];

const MEDICINA: string[] = [
  'Médico', 'Enfermera', 'Cirujano', 'Pediatra', 'Cardiólogo', 'Dentista', 'Estetoscopio', 'Jeringa', 'Vacuna', 'Antibiótico',
  'Pastilla', 'Jarabe', 'Receta médica', 'Radiografía', 'Ecografía', 'Resonancia', 'Análisis de sangre', 'Presión arterial', 'Fiebre', 'Tos',
  'Gripe', 'Alergia', 'Asma', 'Diabetes', 'Migraña', 'Fractura', 'Yeso', 'Venda', 'Curita', 'Camilla',
  'Quirófano', 'Anestesia', 'Suturas', 'Bisturí', 'Mascarilla', 'Guantes médicos', 'Suero', 'Oxígeno médico', 'Pulso', 'Latido',
  'Corazón', 'Pulmones', 'Cerebro', 'Hígado', 'Riñón', 'Estómago', 'Columna vertebral', 'Esqueleto', 'Músculo', 'Arteria',
  'Vena', 'Glóbulo rojo', 'Vitamina', 'Primeros auxilios', 'Urgencias', 'Rehabilitación', 'Fisioterapia', 'Trasplante', 'Diagnóstico', 'Consulta médica'
];

const MUSICA: string[] = [
  'Guitarra', 'Piano', 'Violín', 'Batería', 'Trompeta', 'Flauta', 'Saxofón', 'Arpa', 'Acordeón', 'Maracas',
  'Bajo eléctrico', 'Violonchelo', 'Clarinete', 'Oboe', 'Trombón', 'Tuba', 'Xilófono', 'Pandereta', 'Tambor', 'Ukelele',
  'Órgano', 'Sintetizador', 'Armónica', 'Gaita', 'Bongo', 'Rock', 'Pop', 'Jazz', 'Blues', 'Reguetón',
  'Salsa', 'Tango', 'Flamenco', 'Música clásica', 'Ópera', 'Hip hop', 'Rap', 'Electrónica', 'Cumbia', 'Merengue',
  'Bachata', 'Bolero', 'Balada', 'Heavy metal', 'Punk', 'Melodía', 'Ritmo', 'Armonía', 'Acorde', 'Partitura',
  'Nota musical', 'Compás', 'Coro', 'Orquesta', 'Director de orquesta', 'Concierto', 'Festival', 'Álbum', 'Vinilo', 'Canción'
];

const LITERATURA: string[] = [
  'Novela', 'Cuento', 'Poema', 'Poesía', 'Fábula', 'Leyenda', 'Mito', 'Biografía', 'Autobiografía', 'Ensayo',
  'Crónica', 'Tragedia', 'Comedia', 'Drama', 'Ciencia ficción', 'Fantasía', 'Novela negra', 'Terror', 'Romance', 'Aventura',
  'Soneto', 'Haiku', 'Rima', 'Verso', 'Estrofa', 'Prosa', 'Metáfora', 'Símil', 'Hipérbole', 'Ironía',
  'Narrador', 'Protagonista', 'Antagonista', 'Personaje', 'Trama', 'Desenlace', 'Prólogo', 'Epílogo', 'Capítulo', 'Índice',
  'Autor', 'Escritor', 'Poeta', 'Editor', 'Editorial', 'Imprenta', 'Manuscrito', 'Bestseller', 'Clásico literario', 'Librería',
  'Don Quijote', 'La Odisea', 'La Ilíada', 'Hamlet', 'Romeo y Julieta', 'Cien años de soledad', 'El Principito', 'Drácula', 'Frankenstein', 'Sherlock Holmes'
];

const RAW_ENTRIES: WordEntry[] = [
  ...ANIMALES.map((word) => ({ word, category: 'Animal' as const })),
  ...OBJETOS.map((word) => ({ word, category: 'Objeto' as const })),
  ...COMIDAS.map((word) => ({ word, category: 'Comida' as const })),
  ...BEBIDAS.map((word) => ({ word, category: 'Bebida' as const })),
  ...LUGARES_Y_COSAS.map((word) => ({ word, category: 'Lugar o Cosa' as const })),
  ...DEPORTES.map((word) => ({ word, category: 'Deporte' as const })),
  ...CIENCIA.map((word) => ({ word, category: 'Ciencia' as const })),
  ...MEDICINA.map((word) => ({ word, category: 'Medicina' as const })),
  ...MUSICA.map((word) => ({ word, category: 'Música' as const })),
  ...LITERATURA.map((word) => ({ word, category: 'Literatura' as const })),
];

// Deduplicate preserving first occurrence
const seen = new Set<string>();
export const WORDS_DATABASE: WordEntry[] = RAW_ENTRIES.filter((entry) => {
  const key = entry.word.trim().toLowerCase();
  if (seen.has(key)) return false;
  seen.add(key);
  return true;
});

export function pickRandomWord(usedWords: Set<string>): WordEntry {
  const available = WORDS_DATABASE.filter((entry) => !usedWords.has(entry.word));
  const pool = available.length > 0 ? available : WORDS_DATABASE;
  const index = Math.floor(Math.random() * pool.length);
  return pool[index];
}
