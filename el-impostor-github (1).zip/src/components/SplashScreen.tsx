import React, { useEffect, useRef, useState } from 'react';
import { GameLogo } from './GameLogo';

interface SplashScreenProps {
  onComplete: () => void;
}

export const SplashScreen: React.FC<SplashScreenProps> = ({ onComplete }) => {
  const [progress, setProgress] = useState(0);
  const onCompleteRef = useRef(onComplete);
  onCompleteRef.current = onComplete;

  useEffect(() => {
    const durationMs = 2400;
    const startTime = Date.now();
    let frameId = 0;
    let finishTimer: number | null = null;
    let done = false;

    const tick = () => {
      if (done) return;
      const elapsed = Date.now() - startTime;
      const ratio = Math.min(elapsed / durationMs, 1);
      const eased = 1 - Math.pow(1 - ratio, 2.2);
      setProgress(Math.round(eased * 100));

      if (ratio < 1) {
        frameId = requestAnimationFrame(tick);
      } else {
        done = true;
        finishTimer = window.setTimeout(() => {
          onCompleteRef.current();
        }, 260);
      }
    };

    frameId = requestAnimationFrame(tick);

    // Fallback timer in case requestAnimationFrame is throttled
    const safetyTimer = window.setTimeout(() => {
      if (!done) {
        done = true;
        setProgress(100);
        onCompleteRef.current();
      }
    }, durationMs + 500);

    return () => {
      done = true;
      cancelAnimationFrame(frameId);
      if (finishTimer !== null) window.clearTimeout(finishTimer);
      window.clearTimeout(safetyTimer);
    };
  }, []);

  return (
    <div className="relative min-h-dvh w-full flex flex-col items-center justify-between px-6 py-10 bg-[#0B0E14] overflow-hidden">
      {/* Subtle radial atmospheric glow */}
      <div
        className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_50%_42%,rgba(225,29,72,0.12),transparent_58%)]"
        aria-hidden="true"
      />

      <div className="h-6" aria-hidden="true" />

      {/* Center Logo + Loading Bar */}
      <div className="relative z-10 w-full max-w-xs flex flex-col items-center">
        <GameLogo size="lg" />

        <div className="w-full mt-10">
          <div className="flex items-center justify-between text-xs text-slate-400 mb-2">
            <span>Cargando partida</span>
            <span className="font-mono-nums text-slate-300">{progress}%</span>
          </div>

          <div
            className="w-full h-2 rounded-full bg-[#161C2A] border border-white/10 overflow-hidden"
            role="progressbar"
            aria-valuenow={progress}
            aria-valuemin={0}
            aria-valuemax={100}
            aria-label="Cargando El impostor"
          >
            <div
              className="h-full bg-rose-600 transition-[width] duration-75 ease-out rounded-full"
              style={{ width: `${progress}%` }}
            />
          </div>
        </div>
      </div>

      {/* Bottom Watermark */}
      <footer className="relative z-10 text-center pb-2">
        <p className="text-[11px] tracking-wide text-slate-500">
          created by Kendry
        </p>
      </footer>
    </div>
  );
};
