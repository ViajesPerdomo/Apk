import React from 'react';
import { Minus, Plus, ShieldAlert, Users } from 'lucide-react';
import { sound } from '../utils/sound';

interface PlayerCountSetupProps {
  playerCount: number;
  impostorCount: number;
  onChangeCount: (count: number) => void;
  onChangeImpostorCount: (count: number) => void;
  onConfirm: () => void;
}

const PRESET_COUNTS = [3, 4, 5, 6, 8, 10];
const MIN_PLAYERS = 3;
const MAX_PLAYERS = 16;

export function getMaxImpostors(players: number): number {
  return Math.max(1, Math.floor(players / 2));
}

export const PlayerCountSetup: React.FC<PlayerCountSetupProps> = ({
  playerCount,
  impostorCount,
  onChangeCount,
  onChangeImpostorCount,
  onConfirm,
}) => {
  const maxImpostors = getMaxImpostors(playerCount);

  const handleStepPlayers = (delta: number) => {
    const next = Math.min(MAX_PLAYERS, Math.max(MIN_PLAYERS, playerCount + delta));
    if (next !== playerCount) {
      sound.playTick();
      onChangeCount(next);
    }
  };

  const handleStepImpostors = (delta: number) => {
    const next = Math.min(maxImpostors, Math.max(1, impostorCount + delta));
    if (next !== impostorCount) {
      sound.playTick();
      onChangeImpostorCount(next);
    }
  };

  return (
    <div className="w-full max-w-xl mx-auto flex flex-col items-center">
      <div className="w-full rounded-3xl bg-[#151A26] border border-white/10 p-6 sm:p-10 shadow-2xl shadow-black/40">
        <div className="text-center">
          <div className="inline-flex items-center gap-2 text-xs font-medium text-slate-400 mb-3">
            <Users className="w-4 h-4 text-rose-500" aria-hidden="true" />
            <span>Configuración de partida</span>
          </div>
          <h2 className="font-display text-2xl sm:text-3xl font-bold text-[#F4F1EA] text-balance">
            ¿Cuántos jugadores van a jugar?
          </h2>
          <p className="mt-2 text-sm text-slate-400">
            Elige entre {MIN_PLAYERS} y {MAX_PLAYERS} jugadores y cuántos impostores habrá.
          </p>
        </div>

        {/* Player Count Stepper */}
        <div className="mt-7 flex items-center justify-center gap-6 sm:gap-8">
          <button
            type="button"
            onClick={() => handleStepPlayers(-1)}
            disabled={playerCount <= MIN_PLAYERS}
            aria-label="Disminuir cantidad de jugadores"
            className="w-14 h-14 rounded-2xl bg-[#1D2434] border border-white/10 flex items-center justify-center text-[#F4F1EA] hover:bg-[#252E42] active:scale-95 disabled:opacity-35 disabled:pointer-events-none transition-all cursor-pointer"
          >
            <Minus className="w-6 h-6" />
          </button>

          <div className="min-w-[96px] text-center">
            <span className="font-mono-nums text-6xl sm:text-7xl font-semibold text-[#F4F1EA] leading-none">
              {playerCount}
            </span>
            <p className="mt-1 text-xs text-slate-400">jugadores</p>
          </div>

          <button
            type="button"
            onClick={() => handleStepPlayers(1)}
            disabled={playerCount >= MAX_PLAYERS}
            aria-label="Aumentar cantidad de jugadores"
            className="w-14 h-14 rounded-2xl bg-[#1D2434] border border-white/10 flex items-center justify-center text-[#F4F1EA] hover:bg-[#252E42] active:scale-95 disabled:opacity-35 disabled:pointer-events-none transition-all cursor-pointer"
          >
            <Plus className="w-6 h-6" />
          </button>
        </div>

        {/* Quick Presets */}
        <div className="mt-6">
          <p className="text-xs text-center text-slate-400 mb-2.5">
            Selección rápida
          </p>
          <div className="grid grid-cols-6 gap-2">
            {PRESET_COUNTS.map((count) => {
              const active = playerCount === count;
              return (
                <button
                  key={count}
                  type="button"
                  onClick={() => {
                    sound.playTick();
                    onChangeCount(count);
                  }}
                  className={`h-11 rounded-xl font-mono-nums text-sm font-semibold transition-all cursor-pointer ${
                    active
                      ? 'bg-rose-600 text-white shadow-lg shadow-rose-950/50'
                      : 'bg-[#1D2434] text-slate-300 border border-white/10 hover:bg-[#252E42]'
                  }`}
                >
                  {count}
                </button>
              );
            })}
          </div>
        </div>

        {/* Impostor Count Selector */}
        <div className="mt-7 pt-6 border-t border-white/10">
          <div className="flex items-center justify-between gap-4">
            <div>
              <div className="inline-flex items-center gap-2 text-sm font-semibold text-[#F4F1EA]">
                <ShieldAlert className="w-4 h-4 text-rose-500" aria-hidden="true" />
                <span>Cantidad de impostores</span>
              </div>
              <p className="mt-1 text-xs text-slate-400">
                Máximo {maxImpostors} {maxImpostors === 1 ? 'impostor' : 'impostores'} para {playerCount} jugadores
              </p>
            </div>

            <div className="flex items-center gap-3 shrink-0">
              <button
                type="button"
                onClick={() => handleStepImpostors(-1)}
                disabled={impostorCount <= 1}
                aria-label="Disminuir cantidad de impostores"
                className="w-11 h-11 rounded-xl bg-[#1D2434] border border-white/10 flex items-center justify-center text-[#F4F1EA] hover:bg-[#252E42] active:scale-95 disabled:opacity-35 disabled:pointer-events-none transition-all cursor-pointer"
              >
                <Minus className="w-4 h-4" />
              </button>

              <span className="font-mono-nums text-2xl font-semibold text-rose-400 min-w-[28px] text-center">
                {impostorCount}
              </span>

              <button
                type="button"
                onClick={() => handleStepImpostors(1)}
                disabled={impostorCount >= maxImpostors}
                aria-label="Aumentar cantidad de impostores"
                className="w-11 h-11 rounded-xl bg-[#1D2434] border border-white/10 flex items-center justify-center text-[#F4F1EA] hover:bg-[#252E42] active:scale-95 disabled:opacity-35 disabled:pointer-events-none transition-all cursor-pointer"
              >
                <Plus className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>

        {/* Primary Confirm CTA */}
        <button
          type="button"
          onClick={() => {
            sound.playTick();
            onConfirm();
          }}
          className="mt-7 w-full min-h-[52px] rounded-2xl bg-rose-600 hover:bg-rose-500 active:scale-[0.99] text-white font-semibold text-base transition-all shadow-lg shadow-rose-950/50 cursor-pointer"
        >
          Confirmar cantidad
        </button>
      </div>
    </div>
  );
};
