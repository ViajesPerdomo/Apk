import React, { useState } from 'react';
import { RefreshCw, RotateCcw, Skull, Trophy, UserX } from 'lucide-react';
import { PlayerSession } from './RevealCardStage';
import { sound } from '../utils/sound';

interface RoundEndScreenProps {
  roundNumber: number;
  players: PlayerSession[];
  secretWord: string;
  eliminatedPlayer: PlayerSession | null;
  onAnotherRound: () => void;
  onEliminatePlayer: (playerId: number) => void;
  onContinueAfterElimination: () => void;
  onRestart: () => void;
}

export const RoundEndScreen: React.FC<RoundEndScreenProps> = ({
  roundNumber,
  players,
  secretWord,
  eliminatedPlayer,
  onAnotherRound,
  onEliminatePlayer,
  onContinueAfterElimination,
  onRestart,
}) => {
  const [mode, setMode] = useState<'CHOICE' | 'SELECT_PLAYER'>('CHOICE');
  const [selectedId, setSelectedId] = useState<number | null>(null);

  const alivePlayers = players.filter((p) => !p.eliminated);
  const aliveImpostors = alivePlayers.filter((p) => p.isImpostor);
  const aliveInnocents = alivePlayers.filter((p) => !p.isImpostor);
  const allImpostors = players.filter((p) => p.isImpostor);
  const impostorNames = allImpostors.map((p) => p.name).join(', ');

  // If a player was just eliminated, show the outcome screen
  if (eliminatedPlayer) {
    const eliminatedWasImpostor = eliminatedPlayer.isImpostor;
    const allImpostorsCaught = eliminatedWasImpostor && aliveImpostors.length === 0;
    const impostorsWon = !allImpostorsCaught && aliveImpostors.length >= aliveInnocents.length;

    return (
      <div className="w-full max-w-lg mx-auto">
        <div
          className={`rounded-3xl p-7 sm:p-10 text-center border shadow-2xl shadow-black/50 ${
            allImpostorsCaught
              ? 'bg-[#12201A] border-emerald-500/35'
              : impostorsWon
                ? 'bg-[#2A0B12] border-rose-500/45'
                : 'bg-[#151A26] border-white/10'
          }`}
        >
          <div
            className={`w-14 h-14 mx-auto rounded-2xl flex items-center justify-center mb-5 ${
              allImpostorsCaught || eliminatedWasImpostor
                ? 'bg-emerald-500/15 text-emerald-400'
                : impostorsWon
                  ? 'bg-rose-500/20 text-rose-400'
                  : 'bg-[#1D2434] text-slate-300'
            }`}
          >
            {allImpostorsCaught ? (
              <Trophy className="w-7 h-7" />
            ) : (
              <Skull className="w-7 h-7" />
            )}
          </div>

          {allImpostorsCaught ? (
            <>
              <p className="text-xs font-semibold uppercase tracking-widest text-emerald-400 mb-2">
                Victoria de los jugadores
              </p>
              <h2 className="font-display text-3xl sm:text-4xl font-bold text-[#F4F1EA]">
                ¡{eliminatedPlayer.name} era {allImpostors.length > 1 ? 'el último impostor' : 'el impostor'}!
              </h2>
              <p className="mt-4 text-sm text-slate-300">
                La palabra secreta de la ronda era{' '}
                <strong className="text-white font-semibold">{secretWord}</strong>.
              </p>
            </>
          ) : impostorsWon ? (
            <>
              <p className="text-xs font-semibold uppercase tracking-widest text-rose-400 mb-2">
                {allImpostors.length > 1 ? 'Victoria de los impostores' : 'Victoria del impostor'}
              </p>
              <h2 className="font-display text-3xl sm:text-4xl font-bold text-[#F4F1EA]">
                {eliminatedPlayer.name} {eliminatedWasImpostor ? 'era impostor' : 'era inocente'}
              </h2>
              <p className="mt-4 text-sm text-rose-200/90 leading-relaxed">
                {allImpostors.length > 1 ? 'Los impostores eran' : 'El impostor era'}{' '}
                <strong className="text-white font-semibold">
                  {impostorNames}
                </strong>{' '}
                y la palabra secreta era{' '}
                <strong className="text-white font-semibold">{secretWord}</strong>.
              </p>
            </>
          ) : eliminatedWasImpostor ? (
            <>
              <p className="text-xs text-emerald-400 font-semibold mb-2 font-mono-nums">
                Quedan {alivePlayers.length} jugadores · {aliveImpostors.length}{' '}
                {aliveImpostors.length === 1 ? 'impostor restante' : 'impostores restantes'}
              </p>
              <h2 className="font-display text-3xl font-bold text-[#F4F1EA]">
                ¡{eliminatedPlayer.name} era impostor!
              </h2>
              <p className="mt-3 text-sm text-slate-300">
                Bien hecho, pero todavía {aliveImpostors.length === 1 ? 'queda otro impostor oculto' : `quedan ${aliveImpostors.length} impostores ocultos`}.
              </p>
            </>
          ) : (
            <>
              <p className="text-xs text-slate-400 mb-2 font-mono-nums">
                Quedan {alivePlayers.length} jugadores · {aliveImpostors.length}{' '}
                {aliveImpostors.length === 1 ? 'impostor restante' : 'impostores restantes'}
              </p>
              <h2 className="font-display text-3xl font-bold text-[#F4F1EA]">
                {eliminatedPlayer.name} no era impostor
              </h2>
              <p className="mt-3 text-sm text-slate-400">
                {aliveImpostors.length === 1
                  ? 'El impostor sigue oculto entre los jugadores restantes.'
                  : `Los ${aliveImpostors.length} impostores siguen ocultos entre los jugadores restantes.`}
              </p>
            </>
          )}

          <div className="mt-8 flex flex-col gap-3">
            {!allImpostorsCaught && !impostorsWon && (
              <button
                type="button"
                onClick={() => {
                  sound.playTick();
                  setMode('CHOICE');
                  setSelectedId(null);
                  onContinueAfterElimination();
                }}
                className="w-full min-h-[54px] rounded-2xl bg-rose-600 hover:bg-rose-500 active:scale-[0.99] text-white font-semibold text-base transition-all shadow-lg shadow-rose-950/50 cursor-pointer"
              >
                Siguiente ronda
              </button>
            )}

            <button
              type="button"
              onClick={() => {
                sound.playTick();
                onRestart();
              }}
              className={`w-full min-h-[52px] rounded-2xl font-semibold text-base inline-flex items-center justify-center gap-2 transition-all cursor-pointer ${
                allImpostorsCaught || impostorsWon
                  ? 'bg-rose-600 hover:bg-rose-500 text-white shadow-lg shadow-rose-950/50'
                  : 'bg-[#1D2434] hover:bg-[#252E42] border border-white/10 text-slate-200'
              }`}
            >
              <RotateCcw className="w-4 h-4" aria-hidden="true" />
              <span>Reiniciar</span>
            </button>
          </div>
        </div>
      </div>
    );
  }

  // Choice screen: Another round OR Eliminate someone
  if (mode === 'CHOICE') {
    return (
      <div className="w-full max-w-lg mx-auto">
        <div className="rounded-3xl bg-[#151A26] border border-white/10 p-7 sm:p-10 shadow-2xl shadow-black/50">
          <div className="text-center">
            <p className="text-xs text-slate-400 font-mono-nums mb-2">
              Fin de la ronda {roundNumber}
            </p>
            <h2 className="font-display text-2xl sm:text-3xl font-bold text-[#F4F1EA] text-balance">
              ¿Qué desean hacer ahora?
            </h2>
            <p className="mt-2 text-sm text-slate-400">
              Pueden votar para eliminar a un sospechoso o hacer otra ronda de pistas antes de eliminar.
            </p>
          </div>

          <div className="mt-8 flex flex-col gap-3.5">
            <button
              type="button"
              onClick={() => {
                sound.playTick();
                setMode('SELECT_PLAYER');
              }}
              className="w-full min-h-[56px] px-5 rounded-2xl bg-rose-600 hover:bg-rose-500 active:scale-[0.99] text-white font-semibold text-base inline-flex items-center justify-center gap-2.5 transition-all shadow-lg shadow-rose-950/50 cursor-pointer"
            >
              <UserX className="w-5 h-5" aria-hidden="true" />
              <span>Elegir a quién eliminar</span>
            </button>

            <button
              type="button"
              onClick={() => {
                sound.playTick();
                onAnotherRound();
              }}
              className="w-full min-h-[54px] px-5 rounded-2xl bg-[#1D2434] hover:bg-[#252E42] border border-white/10 text-[#F4F1EA] font-semibold text-base inline-flex items-center justify-center gap-2.5 transition-colors cursor-pointer"
            >
              <RefreshCw className="w-4 h-4 text-slate-300" aria-hidden="true" />
              <span>Hacer otra ronda</span>
            </button>
          </div>

          <div className="mt-6 pt-5 border-t border-white/10 flex justify-center">
            <button
              type="button"
              onClick={() => {
                sound.playTick();
                onRestart();
              }}
              className="min-h-[44px] px-4 rounded-xl text-sm text-slate-400 hover:text-white inline-flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <RotateCcw className="w-4 h-4" aria-hidden="true" />
              <span>Reiniciar partida</span>
            </button>
          </div>
        </div>
      </div>
    );
  }

  // Player selection for elimination
  return (
    <div className="w-full max-w-2xl mx-auto">
      <div className="rounded-3xl bg-[#151A26] border border-white/10 p-6 sm:p-8 shadow-2xl shadow-black/50">
        <div className="flex items-start justify-between gap-4 mb-6">
          <div>
            <p className="text-xs text-slate-400 mb-1.5">Votación de ronda {roundNumber}</p>
            <h2 className="font-display text-2xl sm:text-3xl font-bold text-[#F4F1EA]">
              ¿A quién van a eliminar?
            </h2>
          </div>
          <button
            type="button"
            onClick={() => {
              sound.playTick();
              setMode('CHOICE');
              setSelectedId(null);
            }}
            className="min-h-[44px] px-4 rounded-xl bg-[#1D2434] border border-white/10 text-sm text-slate-300 hover:text-white transition-colors shrink-0 cursor-pointer"
          >
            Volver
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {alivePlayers.map((player) => {
            const isSelected = selectedId === player.id;
            return (
              <button
                key={player.id}
                type="button"
                onClick={() => {
                  sound.playTick();
                  setSelectedId(player.id);
                }}
                className={`min-h-[56px] px-4 py-3 rounded-2xl border text-left flex items-center justify-between transition-all cursor-pointer ${
                  isSelected
                    ? 'bg-rose-600/20 border-rose-500 text-white'
                    : 'bg-[#0E131D] border-white/10 text-slate-200 hover:border-white/25'
                }`}
              >
                <span className="font-medium text-base truncate pr-2">
                  {player.name}
                </span>
                <span
                  className={`text-xs font-medium shrink-0 ${
                    isSelected ? 'text-rose-300' : 'text-slate-500'
                  }`}
                >
                  {isSelected ? 'Seleccionado' : 'Elegir'}
                </span>
              </button>
            );
          })}
        </div>

        <div className="mt-7 flex flex-col sm:flex-row gap-3">
          <button
            type="button"
            disabled={selectedId === null}
            onClick={() => {
              if (selectedId === null) return;
              const target = players.find((p) => p.id === selectedId);
              if (target?.isImpostor) {
                sound.playSuccess();
              } else {
                sound.playEliminate();
              }
              onEliminatePlayer(selectedId);
            }}
            className="flex-1 min-h-[52px] rounded-2xl bg-rose-600 hover:bg-rose-500 disabled:opacity-40 disabled:pointer-events-none text-white font-semibold text-base transition-all cursor-pointer"
          >
            Eliminar jugador seleccionado
          </button>
        </div>
      </div>
    </div>
  );
};
