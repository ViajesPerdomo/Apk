import React, { useCallback, useEffect, useRef, useState } from 'react';
import { Download, Volume2, VolumeX } from 'lucide-react';
import { SplashScreen } from './components/SplashScreen';
import { IntroSequence } from './components/IntroSequence';
import { getMaxImpostors, PlayerCountSetup } from './components/PlayerCountSetup';
import { PlayerNamesSetup } from './components/PlayerNamesSetup';
import { PlayerSession, RevealCardStage } from './components/RevealCardStage';
import { ActiveRoundScreen } from './components/ActiveRoundScreen';
import { RoundEndScreen } from './components/RoundEndScreen';
import { GameLogo } from './components/GameLogo';
import { pickRandomWord, WordEntry } from './data/wordsDatabase';
import { sound } from './utils/sound';

type GamePhase =
  | 'SPLASH'
  | 'INTRO_TEXT'
  | 'PLAYER_COUNT'
  | 'PLAYER_NAMES'
  | 'CARD_REVEAL'
  | 'PLAYING'
  | 'ROUND_END';

function isInstalledApp(): boolean {
  try {
    if (import.meta.env?.VITE_IS_NATIVE_APK === 'true') return true;
    if (typeof window === 'undefined') return false;
    const cap = (
      window as unknown as {
        Capacitor?: { isNativePlatform?: () => boolean };
      }
    ).Capacitor;
    if (cap?.isNativePlatform?.()) return true;
    if (window.location?.protocol === 'capacitor:') return true;
    const isStandalone =
      window.matchMedia?.('(display-mode: standalone)')?.matches ||
      (window.navigator as unknown as { standalone?: boolean })?.standalone === true;
    return Boolean(isStandalone);
  } catch {
    return false;
  }
}

class GameErrorBoundary extends React.Component<
  { children: React.ReactNode },
  { hasError: boolean }
> {
  constructor(props: { children: React.ReactNode }) {
    super(props);
    this.state = { hasError: false };
  }

  static getDerivedStateFromError() {
    return { hasError: true };
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-dvh w-full bg-[#0B0E14] text-[#F4F1EA] flex flex-col items-center justify-center p-6 text-center">
          <h1 className="font-display text-2xl font-bold mb-3">El impostor</h1>
          <p className="text-sm text-slate-400 mb-6">
            Ocurrió un problema al cargar la pantalla.
          </p>
          <button
            type="button"
            onClick={() => window.location.reload()}
            className="min-h-[48px] px-6 rounded-2xl bg-rose-600 text-white font-semibold text-sm cursor-pointer"
          >
            Reintentar
          </button>
        </div>
      );
    }
    return this.props.children;
  }
}

function GameApp() {
  const [phase, setPhase] = useState<GamePhase>('SPLASH');
  const [playerCount, setPlayerCount] = useState<number>(4);
  const [impostorCount, setImpostorCount] = useState<number>(1);
  const [playerNames, setPlayerNames] = useState<string[]>([
    'Jugador 1',
    'Jugador 2',
    'Jugador 3',
    'Jugador 4',
  ]);
  const [players, setPlayers] = useState<PlayerSession[]>([]);
  const [currentRevealIndex, setCurrentRevealIndex] = useState<number>(0);
  const [currentWord, setCurrentWord] = useState<WordEntry | null>(null);
  const [roundNumber, setRoundNumber] = useState<number>(1);
  const [eliminatedPlayer, setEliminatedPlayer] = useState<PlayerSession | null>(null);
  const [isMuted, setIsMuted] = useState<boolean>(false);
  const [showPreviewDownload, setShowPreviewDownload] = useState<boolean>(
    () => !isInstalledApp(),
  );

  const usedWordsRef = useRef<Set<string>>(new Set());

  useEffect(() => {
    const media = window.matchMedia?.('(display-mode: standalone)');
    if (!media) return;
    const update = () => setShowPreviewDownload(!isInstalledApp());
    media.addEventListener?.('change', update);
    return () => media.removeEventListener?.('change', update);
  }, []);

  const handleToggleMute = () => {
    const next = !isMuted;
    sound.muted = next;
    setIsMuted(next);
  };

  const handlePlayerCountChange = (count: number) => {
    setPlayerCount(count);
    const maxImp = getMaxImpostors(count);
    setImpostorCount((prev) => Math.min(prev, maxImp));
  };

  const handleConfirmCount = () => {
    setPlayerNames((prev) =>
      Array.from({ length: playerCount }, (_, idx) => {
        const existing = prev[idx]?.trim();
        return existing ? prev[idx] : `Jugador ${idx + 1}`;
      }),
    );
    setPhase('PLAYER_NAMES');
  };

  const handleNameChange = (index: number, value: string) => {
    setPlayerNames((prev) => {
      const copy = [...prev];
      copy[index] = value;
      return copy;
    });
  };

  const handleConfirmNamesAndStartReveal = () => {
    const chosenEntry = pickRandomWord(usedWordsRef.current);
    usedWordsRef.current.add(chosenEntry.word);

    // Elegir al azar la cantidad seleccionada de impostores
    const indices = Array.from({ length: playerCount }, (_, i) => i);
    for (let i = indices.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [indices[i], indices[j]] = [indices[j], indices[i]];
    }
    const safeImpostorCount = Math.min(impostorCount, getMaxImpostors(playerCount));
    const impostorSet = new Set(indices.slice(0, safeImpostorCount));

    const sessionPlayers: PlayerSession[] = Array.from(
      { length: playerCount },
      (_, idx) => {
        const trimmed = playerNames[idx]?.trim();
        return {
          id: idx,
          name: trimmed || `Jugador ${idx + 1}`,
          isImpostor: impostorSet.has(idx),
          eliminated: false,
        };
      },
    );

    // Aleatorizar el orden en el que se muestra la tarjeta a cada jugador
    for (let i = sessionPlayers.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [sessionPlayers[i], sessionPlayers[j]] = [
        sessionPlayers[j],
        sessionPlayers[i],
      ];
    }

    setCurrentWord(chosenEntry);
    setPlayers(sessionPlayers);
    setCurrentRevealIndex(0);
    setRoundNumber(1);
    setEliminatedPlayer(null);
    setPhase('CARD_REVEAL');
  };

  const handleRestartToCount = useCallback(() => {
    setPlayers([]);
    setCurrentRevealIndex(0);
    setCurrentWord(null);
    setRoundNumber(1);
    setEliminatedPlayer(null);
    setPhase('PLAYER_COUNT');
  }, []);

  const handleEliminatePlayer = (playerId: number) => {
    const target = players.find((p) => p.id === playerId) || null;
    setPlayers((prev) =>
      prev.map((p) => (p.id === playerId ? { ...p, eliminated: true } : p)),
    );
    setEliminatedPlayer(target);
  };

  const handleAnotherRound = () => {
    setEliminatedPlayer(null);
    setRoundNumber((prev) => prev + 1);
    setPhase('PLAYING');
  };

  const handleContinueAfterElimination = () => {
    setEliminatedPlayer(null);
    setRoundNumber((prev) => prev + 1);
    setPhase('PLAYING');
  };

  const handleDownloadZip = async (e: React.MouseEvent) => {
    e.stopPropagation();
    if (import.meta.env?.VITE_IS_NATIVE_APK === 'true') return;
    try {
      const { ZIP_BASE64 } = await import('./data/previewZipPayload');
      if (!ZIP_BASE64) return;
      const binary = atob(ZIP_BASE64);
      const bytes = new Uint8Array(binary.length);
      for (let i = 0; i < binary.length; i++) {
        bytes[i] = binary.charCodeAt(i);
      }
      const blob = new Blob([bytes], { type: 'application/zip' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = 'el-impostor-github.zip';
      document.body.appendChild(link);
      link.click();
      link.remove();
      window.setTimeout(() => URL.revokeObjectURL(url), 4000);
    } catch {
      // Ignore download errors
    }
  };

  const previewDownloadLink = showPreviewDownload ? (
    <button
      type="button"
      onClick={handleDownloadZip}
      className="min-h-[44px] px-3.5 rounded-xl bg-[#151A26] border border-white/15 hover:border-rose-500/50 hover:bg-[#1D2434] text-slate-200 hover:text-white text-xs sm:text-sm font-medium inline-flex items-center gap-2 whitespace-nowrap shrink-0 transition-colors cursor-pointer"
    >
      <Download className="w-4 h-4 text-rose-500" aria-hidden="true" />
      <span>Descargar ZIP</span>
    </button>
  ) : null;

  if (phase === 'SPLASH') {
    return (
      <div className="relative">
        {previewDownloadLink && (
          <div className="fixed top-4 right-4 z-50">{previewDownloadLink}</div>
        )}
        <SplashScreen onComplete={() => setPhase('INTRO_TEXT')} />
      </div>
    );
  }

  if (phase === 'INTRO_TEXT') {
    return (
      <div className="relative">
        {previewDownloadLink && (
          <div className="fixed top-4 right-4 z-50">{previewDownloadLink}</div>
        )}
        <IntroSequence onComplete={() => setPhase('PLAYER_COUNT')} />
      </div>
    );
  }

  const alivePlayers = players.filter((p) => !p.eliminated);
  const aliveCount = alivePlayers.length;
  const aliveImpostorsCount = alivePlayers.filter((p) => p.isImpostor).length;

  return (
    <div className="min-h-dvh w-full bg-[#0B0E14] text-[#F4F1EA] flex flex-col">
      {/* Subtle atmospheric top glow */}
      <div
        className="pointer-events-none fixed inset-0 bg-[radial-gradient(circle_at_50%_0%,rgba(225,29,72,0.08),transparent_55%)]"
        aria-hidden="true"
      />

      {/* Minimal Header */}
      <header className="relative z-10 w-full max-w-5xl mx-auto px-5 sm:px-8 h-16 flex items-center justify-between gap-4">
        <div className="flex items-center gap-3 min-w-0">
          <GameLogo size="sm" showWordmark={false} />
          <span className="font-display font-bold text-lg tracking-tight text-[#F4F1EA] whitespace-nowrap">
            El impostor
          </span>
        </div>

        <div className="flex items-center gap-2.5 shrink-0">
          {previewDownloadLink}

          <button
            type="button"
            onClick={handleToggleMute}
            aria-label={isMuted ? 'Activar sonido' : 'Silenciar sonido'}
            className="min-h-[44px] min-w-[44px] rounded-xl bg-[#151A26] border border-white/10 flex items-center justify-center text-slate-300 hover:text-white hover:bg-[#1D2434] transition-colors cursor-pointer"
          >
            {isMuted ? (
              <VolumeX className="w-5 h-5" />
            ) : (
              <Volume2 className="w-5 h-5" />
            )}
          </button>
        </div>
      </header>

      {/* Main Stage */}
      <main className="relative z-10 flex-1 w-full max-w-5xl mx-auto px-5 sm:px-8 py-6 sm:py-10 flex items-center justify-center">
        {phase === 'PLAYER_COUNT' && (
          <PlayerCountSetup
            playerCount={playerCount}
            impostorCount={impostorCount}
            onChangeCount={handlePlayerCountChange}
            onChangeImpostorCount={setImpostorCount}
            onConfirm={handleConfirmCount}
          />
        )}

        {phase === 'PLAYER_NAMES' && (
          <PlayerNamesSetup
            names={playerNames}
            onChangeName={handleNameChange}
            onBack={() => setPhase('PLAYER_COUNT')}
            onConfirm={handleConfirmNamesAndStartReveal}
          />
        )}

        {phase === 'CARD_REVEAL' && currentWord && (
          <RevealCardStage
            players={players}
            currentIndex={currentRevealIndex}
            impostorCount={impostorCount}
            secretWord={currentWord.word}
            wordCategory={currentWord.category}
            onNextPlayer={() => setCurrentRevealIndex((prev) => prev + 1)}
            onStartGame={() => setPhase('PLAYING')}
          />
        )}

        {phase === 'PLAYING' && (
          <ActiveRoundScreen
            roundNumber={roundNumber}
            aliveCount={aliveCount}
            aliveImpostorsCount={aliveImpostorsCount}
            onFinishRound={() => {
              setEliminatedPlayer(null);
              setPhase('ROUND_END');
            }}
            onRestart={handleRestartToCount}
          />
        )}

        {phase === 'ROUND_END' && currentWord && (
          <RoundEndScreen
            roundNumber={roundNumber}
            players={players}
            secretWord={currentWord.word}
            eliminatedPlayer={eliminatedPlayer}
            onAnotherRound={handleAnotherRound}
            onEliminatePlayer={handleEliminatePlayer}
            onContinueAfterElimination={handleContinueAfterElimination}
            onRestart={handleRestartToCount}
          />
        )}
      </main>
    </div>
  );
}

export default function App() {
  return (
    <GameErrorBoundary>
      <GameApp />
    </GameErrorBoundary>
  );
}
