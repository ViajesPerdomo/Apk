import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.kendry.elimpostor',
  appName: 'El impostor',
  webDir: 'dist',
  android: {
    backgroundColor: '#0B0E14',
  },
};

export default config;
