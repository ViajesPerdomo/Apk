# El impostor

Juego social de deducción y palabras secretas para jugar en grupo.

## Cómo generar el `.apk` en GitHub

1. Descomprime este archivo `.zip` y sube todo su contenido (incluyendo la carpeta oculta `.github/`) a tu repositorio en GitHub en la rama `main` (o `master`).
2. Entra en tu repositorio en GitHub y abre la pestaña **Actions**.
3. El flujo **Compilar APK de El impostor** se ejecutará automáticamente al subir los archivos (también puedes iniciarlo manualmente con **Run workflow**).
4. Cuando termine la compilación, entra en la ejecución completada y descarga el archivo **El-impostor-APK** en la sección **Artifacts** (contiene `El-impostor.apk`).
