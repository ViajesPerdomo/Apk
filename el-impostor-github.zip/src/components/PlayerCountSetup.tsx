import React from 'react';
import { Minus, Plus, Users } from 'lucide-react';
import { sound } from '../utils/sound';

interface PlayerCountSetupProps {
  playerCount: number;
  onChangeCount: (count: number) => void;
  onConfirm: () => void;
}

const PRESET_COUNTS = [3, 4, 5, 6, 8, 10];
const MIN_PLAYERS = 3;
const MAX_PLAYERS = 16;

export const PlayerCountSetup: React.FC<PlayerCountSetupProps> = ({
  playerCount,
  onChangeCount,
  onConfirm,
}) => {
  const handleStep = (delta: number) => {
    const next = Math.min(MAX_PLAYERS, Math.max(MIN_PLAYERS, playerCount + delta));
    if (next !== playerCount) {
      sound.playTick();
      onChangeCount(next);
    }
  };

  return (
    <div className="w-full max-w-xl mx-auto flex flex-col items-center">
      <div className="w-full rounded-3xl bg-[#151A26] border border-white/10 p-6 sm:p-10 shadow-2xl shadow-black/40">
        <div className="text-center">
          <div className="inline-flex items-center gap-2 text-xs font-medium text-slate-400 mb-3">
            <Users className="w-4 h-4 text-rose-500" aria-hidden="true" />
            <span>Configuración de partida</span>
          </div>
          <h2 className="font-display text-2xl sm:text-3xl font-bold text-[#F4F1EA] text-balance">
            ¿Cuántos jugadores van a jugar?
          </h2>
          <p className="mt-2 text-sm text-slate-400">
            Elige entre {MIN_PLAYERS} y {MAX_PLAYERS} jugadores. Uno será el impostor.
          </p>
        </div>

        {/* Big Stepper */}
        <div className="mt-8 flex items-center justify-center gap-6 sm:gap-8">
          <button
            type="button"
            onClick={() => handleStep(-1)}
            disabled={playerCount <= MIN_PLAYERS}
            aria-label="Disminuir cantidad de jugadores"
            className="w-14 h-14 rounded-2xl bg-[#1D2434] border border-white/10 flex items-center justify-center text-[#F4F1EA] hover:bg-[#252E42] active:scale-95 disabled:opacity-35 disabled:pointer-events-none transition-all cursor-pointer"
          >
            <Minus className="w-6 h-6" />
          </button>

          <div className="min-w-[96px] text-center">
            <span className="font-mono-nums text-6xl sm:text-7xl font-semibold text-[#F4F1EA] leading-none">
              {playerCount}
            </span>
            <p className="mt-1 text-xs text-slate-400">jugadores</p>
          </div>

          <button
            type="button"
            onClick={() => handleStep(1)}
            disabled={playerCount >= MAX_PLAYERS}
            aria-label="Aumentar cantidad de jugadores"
            className="w-14 h-14 rounded-2xl bg-[#1D2434] border border-white/10 flex items-center justify-center text-[#F4F1EA] hover:bg-[#252E42] active:scale-95 disabled:opacity-35 disabled:pointer-events-none transition-all cursor-pointer"
          >
            <Plus className="w-6 h-6" />
          </button>
        </div>

        {/* Quick Presets */}
        <div className="mt-8">
          <p className="text-xs text-center text-slate-400 mb-3">
            Selección rápida
          </p>
          <div className="grid grid-cols-6 gap-2">
            {PRESET_COUNTS.map((count) => {
              const active = playerCount === count;
              return (
                <button
                  key={count}
                  type="button"
                  onClick={() => {
                    sound.playTick();
                    onChangeCount(count);
                  }}
                  className={`h-11 rounded-xl font-mono-nums text-sm font-semibold transition-all cursor-pointer ${
                    active
                      ? 'bg-rose-600 text-white shadow-lg shadow-rose-950/50'
                      : 'bg-[#1D2434] text-slate-300 border border-white/10 hover:bg-[#252E42]'
                  }`}
                >
                  {count}
                </button>
              );
            })}
          </div>
        </div>

        {/* Primary Confirm CTA */}
        <button
          type="button"
          onClick={() => {
            sound.playTick();
            onConfirm();
          }}
          className="mt-8 w-full min-h-[52px] rounded-2xl bg-rose-600 hover:bg-rose-500 active:scale-[0.99] text-white font-semibold text-base transition-all shadow-lg shadow-rose-950/50 cursor-pointer"
        >
          Confirmar cantidad
        </button>
      </div>
    </div>
  );
};
