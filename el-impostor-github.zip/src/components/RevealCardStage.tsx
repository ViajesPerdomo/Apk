import React, { useEffect, useRef, useState } from 'react';
import { Eye, EyeOff, Fingerprint } from 'lucide-react';
import { WordCategory } from '../data/wordsDatabase';
import { sound } from '../utils/sound';

export interface PlayerSession {
  id: number;
  name: string;
  isImpostor: boolean;
  eliminated: boolean;
}

interface RevealCardStageProps {
  players: PlayerSession[];
  currentIndex: number;
  secretWord: string;
  wordCategory: WordCategory;
  onNextPlayer: () => void;
  onStartGame: () => void;
}

export const RevealCardStage: React.FC<RevealCardStageProps> = ({
  players,
  currentIndex,
  secretWord,
  wordCategory,
  onNextPlayer,
  onStartGame,
}) => {
  const [isHolding, setIsHolding] = useState(false);
  const [hasPeeked, setHasPeeked] = useState(false);
  const cardRef = useRef<HTMLDivElement | null>(null);

  const currentPlayer = players[currentIndex];
  const isLastPlayer = currentIndex === players.length - 1;

  // Reset hold & peek state cleanly when moving to next player
  useEffect(() => {
    setIsHolding(false);
    setHasPeeked(false);
  }, [currentIndex]);

  // Safety listener: if pointer is released anywhere outside the card, always flip back
  useEffect(() => {
    if (!isHolding) return;

    const release = () => {
      setIsHolding(false);
      sound.playFlip(false);
    };

    window.addEventListener('pointerup', release);
    window.addEventListener('pointercancel', release);
    window.addEventListener('blur', release);
    return () => {
      window.removeEventListener('pointerup', release);
      window.removeEventListener('pointercancel', release);
      window.removeEventListener('blur', release);
    };
  }, [isHolding]);

  const startHold = () => {
    if (isHolding) return;
    setIsHolding(true);
    setHasPeeked(true);
    if (currentPlayer.isImpostor) {
      sound.playImpostorReveal();
    } else {
      sound.playFlip(true);
    }
  };

  const endHold = () => {
    if (!isHolding) return;
    setIsHolding(false);
    sound.playFlip(false);
  };

  return (
    <div className="w-full max-w-md mx-auto flex flex-col items-center">
      {/* Turn Indicator */}
      <div className="mb-5 text-center">
        <p className="text-xs text-slate-400 font-mono-nums">
          Jugador {currentIndex + 1} de {players.length}
        </p>
      </div>

      {/* Interactive Hold-to-Flip Card */}
      <div
        ref={cardRef}
        role="button"
        tabIndex={0}
        aria-label={`Tarjeta de ${currentPlayer.name}. Mantén presionado para revelar tu rol.`}
        onPointerDown={(e) => {
          e.preventDefault();
          try {
            e.currentTarget.setPointerCapture(e.pointerId);
          } catch {
            // Ignore if pointer capture is unsupported
          }
          startHold();
        }}
        onPointerUp={(e) => {
          e.preventDefault();
          endHold();
        }}
        onPointerCancel={endHold}
        onContextMenu={(e) => e.preventDefault()}
        onKeyDown={(e) => {
          if ((e.key === ' ' || e.key === 'Enter') && !e.repeat) {
            e.preventDefault();
            startHold();
          }
        }}
        onKeyUp={(e) => {
          if (e.key === ' ' || e.key === 'Enter') {
            e.preventDefault();
            endHold();
          }
        }}
        className="card-perspective w-full h-[380px] sm:h-[420px] touch-none select-none cursor-pointer focus:outline-none focus-visible:ring-2 focus-visible:ring-rose-500 rounded-3xl"
      >
        <div className={`card-inner ${isHolding ? 'is-flipped' : ''}`}>
          {/* FRONT FACE: Player's Name */}
          <div className="card-face rounded-3xl bg-[#151A26] border border-white/15 p-8 flex flex-col items-center justify-between shadow-2xl shadow-black/60">
            <div className="w-full flex items-center justify-between text-xs text-slate-400">
              <span>Turno secreto</span>
              <EyeOff className="w-4 h-4 text-slate-500" aria-hidden="true" />
            </div>

            <div className="text-center px-2">
              <p className="text-xs text-slate-400 mb-2">Esta tarjeta es para</p>
              <h2 className="font-display text-3xl sm:text-4xl font-bold text-[#F4F1EA] break-words">
                {currentPlayer.name}
              </h2>
            </div>

            <div className="w-full flex flex-col items-center gap-2 pt-4 border-t border-white/10">
              <div className="w-11 h-11 rounded-full bg-rose-600/15 border border-rose-500/30 flex items-center justify-center text-rose-400">
                <Fingerprint className="w-5 h-5" aria-hidden="true" />
              </div>
              <p className="text-xs sm:text-sm text-slate-300 text-center">
                Toca y mantén presionado para voltear
              </p>
            </div>
          </div>

          {/* BACK FACE: Word OR Impostor Signal (never shows word to impostor) */}
          <div
            className={`card-face card-face-back rounded-3xl p-8 flex flex-col items-center justify-between shadow-2xl shadow-black/60 border ${
              currentPlayer.isImpostor
                ? 'bg-[#2A0B12] border-rose-500/50'
                : 'bg-[#F4F1EA] border-stone-300 text-[#111622]'
            }`}
          >
            <div
              className={`w-full flex items-center justify-between text-xs ${
                currentPlayer.isImpostor ? 'text-rose-200/80' : 'text-stone-500'
              }`}
            >
              <span>{currentPlayer.name}</span>
              <Eye className="w-4 h-4" aria-hidden="true" />
            </div>

            {currentPlayer.isImpostor ? (
              <div className="text-center px-2">
                <p className="text-xs uppercase tracking-[0.22em] text-rose-300 font-semibold mb-3">
                  Tu rol secreto
                </p>
                <h3 className="font-display text-4xl sm:text-5xl font-bold text-white tracking-tight">
                  IMPOSTOR
                </h3>
                <p className="mt-4 text-sm text-rose-200/90 max-w-[240px] mx-auto leading-relaxed">
                  No conoces la palabra secreta. Disimula y escucha con atención.
                </p>
              </div>
            ) : (
              <div className="text-center px-2">
                <p className="text-xs text-stone-500 mb-2">
                  Palabra secreta · {wordCategory}
                </p>
                <h3 className="font-display text-3xl sm:text-4xl font-bold text-[#0B0E14] break-words">
                  {secretWord}
                </h3>
                <p className="mt-4 text-xs sm:text-sm text-stone-600 max-w-[240px] mx-auto leading-relaxed">
                  Memoriza la palabra y da pistas sin delatarla al impostor.
                </p>
              </div>
            )}

            <div
              className={`w-full pt-4 border-t text-center text-xs ${
                currentPlayer.isImpostor
                  ? 'border-rose-400/20 text-rose-200/80'
                  : 'border-stone-300 text-stone-500'
              }`}
            >
              Suelta para ocultar la tarjeta
            </div>
          </div>
        </div>
      </div>

      {/* Action Button Below Card: appears after player has peeked & released */}
      <div className="w-full mt-6 min-h-[60px] flex items-center justify-center">
        {hasPeeked && !isHolding ? (
          <button
            type="button"
            onClick={() => {
              sound.playTick();
              if (isLastPlayer) {
                onStartGame();
              } else {
                onNextPlayer();
              }
            }}
            className="w-full min-h-[54px] rounded-2xl bg-rose-600 hover:bg-rose-500 active:scale-[0.99] text-white font-semibold text-base transition-all shadow-lg shadow-rose-950/50 cursor-pointer"
          >
            {isLastPlayer ? 'Empezar juego' : 'Pasar a otro jugador'}
          </button>
        ) : (
          <p className="text-xs text-slate-500 text-center">
            {isHolding
              ? 'Suelta la tarjeta cuando hayas visto tu rol'
              : 'Mantén presionada la tarjeta para continuar'}
          </p>
        )}
      </div>
    </div>
  );
};
