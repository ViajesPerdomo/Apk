import React from 'react';
import { ArrowLeft, UserRoundPen } from 'lucide-react';
import { sound } from '../utils/sound';

interface PlayerNamesSetupProps {
  names: string[];
  onChangeName: (index: number, value: string) => void;
  onBack: () => void;
  onConfirm: () => void;
}

export const PlayerNamesSetup: React.FC<PlayerNamesSetupProps> = ({
  names,
  onChangeName,
  onBack,
  onConfirm,
}) => {
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    sound.playTick();
    onConfirm();
  };

  return (
    <div className="w-full max-w-3xl mx-auto">
      <form
        onSubmit={handleSubmit}
        className="rounded-3xl bg-[#151A26] border border-white/10 p-6 sm:p-8 shadow-2xl shadow-black/40"
      >
        <div className="flex items-start justify-between gap-4 mb-6">
          <div>
            <div className="inline-flex items-center gap-2 text-xs font-medium text-slate-400 mb-2">
              <UserRoundPen className="w-4 h-4 text-rose-500" aria-hidden="true" />
              <span>Nombres de los jugadores</span>
            </div>
            <h2 className="font-display text-2xl sm:text-3xl font-bold text-[#F4F1EA]">
              ¿Quiénes juegan hoy?
            </h2>
            <p className="mt-1.5 text-sm text-slate-400">
              Escribe el nombre de cada jugador o déjalo con su nombre por defecto.
            </p>
          </div>

          <button
            type="button"
            onClick={() => {
              sound.playTick();
              onBack();
            }}
            className="min-h-[44px] px-3.5 rounded-xl bg-[#1D2434] border border-white/10 text-slate-300 hover:text-white hover:bg-[#252E42] text-sm font-medium inline-flex items-center gap-1.5 shrink-0 transition-colors cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Cambiar</span>
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5 max-h-[52vh] overflow-y-auto pr-1">
          {names.map((name, index) => {
            const defaultLabel = `Jugador ${index + 1}`;
            return (
              <div key={index} className="flex flex-col gap-1.5">
                <label
                  htmlFor={`player-name-${index}`}
                  className="text-xs font-medium text-slate-400 flex items-center justify-between px-1"
                >
                  <span>{defaultLabel}</span>
                  <span className="font-mono-nums text-slate-500">
                    #{index + 1}
                  </span>
                </label>
                <input
                  id={`player-name-${index}`}
                  type="text"
                  maxLength={24}
                  value={name}
                  placeholder={defaultLabel}
                  onChange={(e) => onChangeName(index, e.target.value)}
                  onFocus={(e) => e.target.select()}
                  className="w-full min-h-[48px] px-4 rounded-xl bg-[#0E131D] border border-white/10 text-[#F4F1EA] placeholder:text-slate-500 text-base focus:outline-none focus:border-rose-500 focus:ring-1 focus:ring-rose-500 transition-colors"
                />
              </div>
            );
          })}
        </div>

        <div className="mt-7 pt-5 border-t border-white/10 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-xs text-slate-400 text-center sm:text-left">
            Si un campo queda vacío se usará su nombre por defecto.
          </p>
          <button
            type="submit"
            className="w-full sm:w-auto min-h-[52px] px-8 rounded-2xl bg-rose-600 hover:bg-rose-500 active:scale-[0.99] text-white font-semibold text-base transition-all shadow-lg shadow-rose-950/50 whitespace-nowrap cursor-pointer"
          >
            Sortear palabra y empezar
          </button>
        </div>
      </form>
    </div>
  );
};
