import React from 'react';

interface GameLogoProps {
  size?: 'sm' | 'md' | 'lg';
  showWordmark?: boolean;
}

export const GameLogo: React.FC<GameLogoProps> = ({
  size = 'lg',
  showWordmark = true,
}) => {
  const iconDimensions =
    size === 'lg' ? 'w-24 h-24' : size === 'md' ? 'w-14 h-14' : 'w-9 h-9';

  return (
    <div className="flex flex-col items-center select-none">
      <div
        className={`${iconDimensions} relative flex items-center justify-center rounded-2xl bg-[#151A26] border border-white/10 shadow-2xl shadow-black/60`}
      >
        <svg
          viewBox="0 0 96 96"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          className="w-3/4 h-3/4"
          aria-hidden="true"
        >
          {/* Outer dossier frame */}
          <rect
            x="14"
            y="10"
            width="68"
            height="76"
            rx="10"
            stroke="#F4F1EA"
            strokeOpacity="0.22"
            strokeWidth="2"
          />
          {/* Stylized silhouette / hood */}
          <path
            d="M48 22C34.7452 22 24 32.7452 24 46V64C24 67.3137 26.6863 70 30 70H66C69.3137 70 72 67.3137 72 64V46C72 32.7452 61.2548 22 48 22Z"
            fill="#0B0E14"
            stroke="#F4F1EA"
            strokeOpacity="0.85"
            strokeWidth="2.5"
          />
          {/* Mask visor */}
          <path
            d="M32 45C32 41.6863 34.6863 39 38 39H58C61.3137 39 64 41.6863 64 45V48C64 51.3137 61.3137 54 58 54H52.5C50.7 54 49.5 51.5 48 51.5C46.5 51.5 45.3 54 43.5 54H38C34.6863 54 32 51.3137 32 48V45Z"
            fill="#E11D48"
          />
          {/* Eye slits */}
          <circle cx="40.5" cy="46.5" r="2.2" fill="#0B0E14" />
          <circle cx="55.5" cy="46.5" r="2.2" fill="#0B0E14" />
        </svg>
      </div>

      {showWordmark && (
        <div className="mt-5 text-center">
          <h1
            className={`font-display font-bold tracking-tight text-[#F4F1EA] ${
              size === 'lg'
                ? 'text-4xl sm:text-5xl'
                : size === 'md'
                  ? 'text-2xl'
                  : 'text-lg'
            }`}
          >
            El impostor
          </h1>
        </div>
      )}
    </div>
  );
};
