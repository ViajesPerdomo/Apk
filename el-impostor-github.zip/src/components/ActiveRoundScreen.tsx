import React from 'react';
import { RotateCcw, ShieldAlert } from 'lucide-react';
import { sound } from '../utils/sound';

interface ActiveRoundScreenProps {
  roundNumber: number;
  aliveCount: number;
  onFinishRound: () => void;
  onRestart: () => void;
}

export const ActiveRoundScreen: React.FC<ActiveRoundScreenProps> = ({
  roundNumber,
  aliveCount,
  onFinishRound,
  onRestart,
}) => {
  return (
    <div className="w-full max-w-md mx-auto flex flex-col items-center">
      <div className="w-full rounded-3xl bg-[#151A26] border border-white/10 p-7 sm:p-10 text-center shadow-2xl shadow-black/50">
        <p className="text-xs text-slate-400 font-mono-nums">
          Ronda {roundNumber} · {aliveCount} jugadores activos
        </p>

        <h2 className="mt-3 font-display text-3xl sm:text-4xl font-bold text-[#F4F1EA]">
          Ronda en curso
        </h2>

        <p className="mt-3 text-sm text-slate-400 leading-relaxed">
          Cada jugador da una pista relacionada con la palabra. Cuando terminen de hablar, decidan qué hacer.
        </p>

        <div className="mt-8 flex flex-col gap-3">
          <button
            type="button"
            onClick={() => {
              sound.playTick();
              onFinishRound();
            }}
            className="w-full min-h-[54px] rounded-2xl bg-rose-600 hover:bg-rose-500 active:scale-[0.99] text-white font-semibold text-base inline-flex items-center justify-center gap-2 transition-all shadow-lg shadow-rose-950/50 cursor-pointer"
          >
            <ShieldAlert className="w-5 h-5" aria-hidden="true" />
            <span>Finalizar ronda</span>
          </button>

          <button
            type="button"
            onClick={() => {
              sound.playTick();
              onRestart();
            }}
            className="w-full min-h-[50px] rounded-2xl bg-[#1D2434] hover:bg-[#252E42] border border-white/10 text-slate-200 font-medium text-sm inline-flex items-center justify-center gap-2 transition-colors cursor-pointer"
          >
            <RotateCcw className="w-4 h-4" aria-hidden="true" />
            <span>Reiniciar</span>
          </button>
        </div>
      </div>
    </div>
  );
};
