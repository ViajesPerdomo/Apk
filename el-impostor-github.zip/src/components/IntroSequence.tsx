import React, { useEffect, useRef, useState } from 'react';
import { sound } from '../utils/sound';

interface IntroSequenceProps {
  onComplete: () => void;
}

const PHRASE_WORDS = ['Cuidado,', 'hay', 'un', 'impostor', 'entre', 'nosotros'];

export const IntroSequence: React.FC<IntroSequenceProps> = ({ onComplete }) => {
  const [visibleCount, setVisibleCount] = useState(0);
  const [isAccelerated, setIsAccelerated] = useState(false);
  const completedRef = useRef(false);

  const isDone = visibleCount >= PHRASE_WORDS.length;

  useEffect(() => {
    if (isDone) {
      const delay = isAccelerated ? 450 : 1250;
      const timer = window.setTimeout(() => {
        if (!completedRef.current) {
          completedRef.current = true;
          onComplete();
        }
      }, delay);
      return () => window.clearTimeout(timer);
    }

    const intervalMs = isAccelerated ? 130 : visibleCount === 0 ? 320 : 540;
    const timer = window.setTimeout(() => {
      sound.playTick();
      setVisibleCount((prev) => prev + 1);
    }, intervalMs);

    return () => window.clearTimeout(timer);
  }, [visibleCount, isAccelerated, isDone, onComplete]);

  const handleScreenTap = () => {
    if (isDone) {
      if (!completedRef.current) {
        completedRef.current = true;
        onComplete();
      }
      return;
    }

    if (!isAccelerated) {
      setIsAccelerated(true);
      sound.playTick();
      setVisibleCount((prev) => Math.min(prev + 1, PHRASE_WORDS.length));
    } else {
      // Second tap completes the sentence immediately
      setVisibleCount(PHRASE_WORDS.length);
    }
  };

  return (
    <div
      onClick={handleScreenTap}
      onKeyDown={(e) => {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          handleScreenTap();
        }
      }}
      role="button"
      tabIndex={0}
      aria-label="Cuidado, hay un impostor entre nosotros. Toca la pantalla para apresurar."
      className="relative min-h-dvh w-full flex flex-col items-center justify-between px-6 py-12 bg-[#0B0E14] cursor-pointer select-none focus:outline-none"
    >
      <div
        className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(225,29,72,0.09),transparent_60%)]"
        aria-hidden="true"
      />

      <div className="h-6" aria-hidden="true" />

      <div className="relative z-10 max-w-3xl w-full text-center px-2">
        <p className="font-display text-3xl sm:text-5xl lg:text-6xl font-bold leading-tight tracking-tight text-balance">
          {PHRASE_WORDS.map((word, index) => {
            const visible = index < visibleCount;
            const isImpostorWord = word.toLowerCase() === 'impostor';

            return (
              <span
                key={`${word}-${index}`}
                className={`inline-block mx-1.5 sm:mx-2.5 transition-all duration-300 ease-out ${
                  visible
                    ? 'opacity-100 translate-y-0 scale-100'
                    : 'opacity-0 translate-y-3 scale-95'
                } ${isImpostorWord ? 'text-rose-500' : 'text-[#F4F1EA]'}`}
              >
                {word}
              </span>
            );
          })}
        </p>
      </div>

      <div className="relative z-10 pb-2 text-center">
        <p className="text-xs sm:text-sm text-slate-400">
          {isDone
            ? 'Toca la pantalla para continuar'
            : 'Toca la pantalla para apresurar'}
        </p>
      </div>
    </div>
  );
};
